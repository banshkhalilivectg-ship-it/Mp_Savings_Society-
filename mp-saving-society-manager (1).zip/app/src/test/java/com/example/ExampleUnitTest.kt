package com.example

import com.example.data.model.MemberEntity
import com.example.data.model.PaymentAllocationEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity
import com.example.domain.ArrearsCalculator
import com.example.domain.BengaliUtils
import com.example.domain.PaymentStatusType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testBengaliDigits() {
        assertEquals("১২৩৪৫", BengaliUtils.toBengaliDigits("12345"))
        assertEquals("৳ ৫০০", BengaliUtils.formatTaka(500.0))
        assertEquals("৳ ১০০০", BengaliUtils.formatTaka(1000.0))
    }

    @Test
    fun testBengaliMonthNames() {
        assertEquals("জানুয়ারি", BengaliUtils.getBengaliMonthName(1))
        assertEquals("অক্টোবর", BengaliUtils.getBengaliMonthName(10))
        assertEquals("ডিসেম্বর", BengaliUtils.getBengaliMonthName(12))
    }

    @Test
    fun testAmountInBengaliWords() {
        assertEquals("পাঁচ শত টাকা মাত্র", BengaliUtils.amountInBengaliWords(500.0))
        assertEquals("এক হাজার টাকা মাত্র", BengaliUtils.amountInBengaliWords(1000.0))
        assertEquals("দুই হাজার পাঁচ শত টাকা মাত্র", BengaliUtils.amountInBengaliWords(2500.0))
    }

    @Test
    fun testArrearsCalculation() {
        val member = MemberEntity(
            id = 1,
            memberNumber = "MP-001",
            bengaliName = "রফিকুল ইসলাম",
            englishName = "Rafiqul Islam",
            mobileNumber = "01812345671",
            address = "বাঁশখালী",
            joinDate = "2026-01-01"
        )

        val settings = SocietySettingsEntity(
            monthlySavingsAmount = 500.0,
            startYear = 2026,
            startMonth = 1
        )

        // Member paid for 2 months (January & February)
        val allocs = listOf(
            PaymentAllocationEntity(1, 1, 1, 1, 2026, 500.0),
            PaymentAllocationEntity(2, 2, 1, 2, 2026, 500.0)
        )

        val txs = listOf(
            SavingsTransactionEntity(
                id = 1,
                transactionId = "TXN-01",
                receiptNumber = "RCP-01",
                memberId = 1,
                month = 1,
                year = 2026,
                amount = 500.0,
                paymentDate = "2026-01-10",
                paymentMethod = "CASH",
                recordedBy = "Admin"
            ),
            SavingsTransactionEntity(
                id = 2,
                transactionId = "TXN-02",
                receiptNumber = "RCP-02",
                memberId = 1,
                month = 2,
                year = 2026,
                amount = 500.0,
                paymentDate = "2026-02-10",
                paymentMethod = "CASH",
                recordedBy = "Admin"
            )
        )

        val summary = ArrearsCalculator.calculateForMember(
            member = member,
            settings = settings,
            allocations = allocs,
            transactions = txs,
            targetYear = 2026,
            targetMonth = 10 // Up to October: 10 elapsed months
        )

        // Total due = 10 * 500 = 5000
        assertEquals(5000.0, summary.totalDue, 0.01)
        // Total paid = 1000
        assertEquals(1000.0, summary.totalPaid, 0.01)
        // Total arrears = 4000
        assertEquals(4000.0, summary.totalArrears, 0.01)
        // Unpaid months = 8 (March to October)
        assertEquals(8, summary.unpaidMonthsCount)
        assertEquals(2, summary.fullyPaidMonthsCount)

        // Check January is FULLY_PAID
        assertEquals(PaymentStatusType.FULLY_PAID, summary.monthlyItems[0].status)
        // Check March is UNPAID
        assertEquals(PaymentStatusType.UNPAID, summary.monthlyItems[2].status)
    }
}
