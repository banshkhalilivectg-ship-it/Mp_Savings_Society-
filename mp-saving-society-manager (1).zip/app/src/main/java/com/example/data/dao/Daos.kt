package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AuditLogEntity
import com.example.data.model.BankTransactionEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.MemberEntity
import com.example.data.model.NoticeEntity
import com.example.data.model.PaymentAllocationEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {
    @Query("SELECT * FROM members ORDER BY memberNumber ASC")
    fun getAllMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE status = 'ACTIVE' ORDER BY memberNumber ASC")
    fun getActiveMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: Long): MemberEntity?

    @Query("SELECT * FROM members WHERE memberNumber = :memberNumber LIMIT 1")
    suspend fun getMemberByNumber(memberNumber: String): MemberEntity?

    @Query("SELECT * FROM members WHERE mobileNumber = :mobile LIMIT 1")
    suspend fun getMemberByMobile(mobile: String): MemberEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertMember(member: MemberEntity): Long

    @Update
    suspend fun updateMember(member: MemberEntity)

    @Query("SELECT COUNT(*) FROM members WHERE status = 'ACTIVE'")
    fun getActiveMemberCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM members")
    fun getTotalMemberCount(): Flow<Int>
}

@Dao
interface SavingsDao {
    @Query("SELECT * FROM savings_transactions ORDER BY createdAt DESC")
    fun getAllTransactions(): Flow<List<SavingsTransactionEntity>>

    @Query("SELECT * FROM savings_transactions WHERE memberId = :memberId ORDER BY year DESC, month DESC, createdAt DESC")
    fun getTransactionsForMember(memberId: Long): Flow<List<SavingsTransactionEntity>>

    @Query("SELECT * FROM savings_transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: Long): SavingsTransactionEntity?

    @Query("SELECT * FROM savings_transactions WHERE receiptNumber = :receiptNumber LIMIT 1")
    suspend fun getTransactionByReceiptNumber(receiptNumber: String): SavingsTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: SavingsTransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: SavingsTransactionEntity)

    // Allocations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllocations(allocations: List<PaymentAllocationEntity>)

    @Query("SELECT * FROM payment_allocations WHERE memberId = :memberId AND isReversed = 0")
    fun getAllocationsForMember(memberId: Long): Flow<List<PaymentAllocationEntity>>

    @Query("SELECT * FROM payment_allocations WHERE isReversed = 0")
    fun getAllAllocations(): Flow<List<PaymentAllocationEntity>>

    @Query("UPDATE payment_allocations SET isReversed = 1 WHERE transactionId = :transactionId")
    suspend fun reverseAllocationsForTransaction(transactionId: Long)

    @Query("SELECT SUM(amount) FROM savings_transactions WHERE isReversed = 0")
    fun getTotalSavingsCollected(): Flow<Double?>

    @Query("SELECT SUM(amount) FROM savings_transactions WHERE month = :month AND year = :year AND isReversed = 0")
    fun getCurrentMonthSavings(month: Int, year: Int): Flow<Double?>
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY date DESC, createdAt DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Query("SELECT SUM(amount) FROM expenses")
    fun getTotalExpenses(): Flow<Double?>
}

@Dao
interface BankDao {
    @Query("SELECT * FROM bank_transactions ORDER BY date DESC, createdAt DESC")
    fun getAllBankTransactions(): Flow<List<BankTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankTransaction(tx: BankTransactionEntity): Long

    @Query("SELECT * FROM bank_transactions WHERE type = :type ORDER BY date DESC")
    fun getTransactionsByType(type: String): Flow<List<BankTransactionEntity>>
}

@Dao
interface NoticeDao {
    @Query("SELECT * FROM notices WHERE isDraft = 0 ORDER BY createdAt DESC")
    fun getPublishedNotices(): Flow<List<NoticeEntity>>

    @Query("SELECT * FROM notices ORDER BY createdAt DESC")
    fun getAllNotices(): Flow<List<NoticeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotice(notice: NoticeEntity): Long

    @Update
    suspend fun updateNotice(notice: NoticeEntity)

    @Query("DELETE FROM notices WHERE id = :id")
    suspend fun deleteNotice(id: Long)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Insert
    suspend fun insertLog(log: AuditLogEntity)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM society_settings WHERE id = 1 LIMIT 1")
    fun getSettingsFlow(): Flow<SocietySettingsEntity?>

    @Query("SELECT * FROM society_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettings(): SocietySettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: SocietySettingsEntity)
}

@Dao
interface AdminUserDao {
    @Query("SELECT * FROM admin_users ORDER BY isMaster DESC, id ASC")
    fun getAllAdmins(): Flow<List<com.example.data.model.AdminUserEntity>>

    @Query("SELECT * FROM admin_users WHERE email = :email LIMIT 1")
    suspend fun getAdminByEmail(email: String): com.example.data.model.AdminUserEntity?

    @Query("SELECT * FROM admin_users WHERE (email = :identifier OR phone = :identifier) LIMIT 1")
    suspend fun findAdminByIdentifier(identifier: String): com.example.data.model.AdminUserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmin(admin: com.example.data.model.AdminUserEntity): Long

    @Update
    suspend fun updateAdmin(admin: com.example.data.model.AdminUserEntity)

    @Query("DELETE FROM admin_users WHERE id = :id AND isMaster = 0")
    suspend fun deleteAdmin(id: Long)
}
