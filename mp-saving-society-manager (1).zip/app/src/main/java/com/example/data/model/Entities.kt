package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "members")
data class MemberEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val memberNumber: String, // e.g. "MP-001"
    val bengaliName: String,
    val englishName: String,
    val mobileNumber: String,
    val address: String,
    val joinDate: String, // YYYY-MM-DD
    val status: String = "ACTIVE", // ACTIVE, SUSPENDED, ARCHIVED
    val photoUri: String? = null,
    val notes: String? = null,
    val linkedEmail: String? = null,
    val linkedPin: String = "1234",
    val role: String = "MEMBER" // MEMBER or ADMIN
)

@Entity(tableName = "savings_transactions")
data class SavingsTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val transactionId: String, // e.g. "TXN-202610-001"
    val receiptNumber: String, // e.g. "RCP-202610-001"
    val memberId: Long,
    val month: Int, // 1 to 12
    val year: Int,
    val amount: Double,
    val paymentDate: String, // YYYY-MM-DD
    val paymentMethod: String, // CASH, BANK, BKASH, NAGAD
    val recordedBy: String,
    val note: String? = null,
    val status: String = "COMPLETED", // COMPLETED, REVERSED
    val isReversed: Boolean = false,
    val reversalReason: String? = null,
    val reversedAt: String? = null,
    val reversedBy: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "payment_allocations")
data class PaymentAllocationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val transactionId: Long,
    val memberId: Long,
    val month: Int,
    val year: Int,
    val allocatedAmount: Double,
    val isReversed: Boolean = false
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // YYYY-MM-DD
    val category: String, // OFFICE, MEETING, WELFARE, PRINTING, MISC
    val amount: Double,
    val description: String,
    val voucherRef: String? = null,
    val recordedBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "bank_transactions")
data class BankTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // YYYY-MM-DD
    val type: String, // DEPOSIT, WITHDRAWAL, TRANSFER_CASH_TO_BANK, TRANSFER_BANK_TO_CASH
    val amount: Double,
    val bankName: String,
    val accountNo: String,
    val reference: String,
    val description: String,
    val recordedBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notices")
data class NoticeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val type: String = "GENERAL", // GENERAL, MEETING, SAVINGS_REMINDER, WELFARE
    val publishDate: String, // YYYY-MM-DD
    val expiryDate: String? = null,
    val isDraft: Boolean = false,
    val priority: String = "NORMAL", // NORMAL, HIGH, URGENT
    val author: String = "কার্যনির্বাহী পরিষদ",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val actorName: String,
    val actorRole: String,
    val action: String, // MEMBER_CREATED, DEPOSIT_RECORDED, TRANSACTION_REVERSED, EXPENSE_RECORDED, etc.
    val entityType: String,
    val entityId: String,
    val details: String
)

@Entity(tableName = "admin_users")
data class AdminUserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    val passwordHash: String,
    val roleTitleBn: String = "সহকারী এডমিন", // মাস্টার সুপার এডমিন, সহকারী এডমিন, কোষাধ্যক্ষ, হিসাব নিরীক্ষক/এডিটর
    val roleKey: String = "ASSISTANT_ADMIN", // SUPER_ADMIN, ASSISTANT_ADMIN, TREASURER, EDITOR
    val status: String = "ACTIVE", // ACTIVE, SUSPENDED, INVITED
    val invitedAt: Long = System.currentTimeMillis(),
    val invitedBy: String = "মাস্টার এডমিন",
    val isMaster: Boolean = false
)

@Entity(tableName = "society_settings")
data class SocietySettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val societyNameBn: String = "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
    val societyNameEn: String = "MP Saving Society",
    val location: String = "বাঁশখালী, চট্টগ্রাম, বাংলাদেশ",
    val monthlySavingsAmount: Double = 500.0,
    val startYear: Int = 2025,
    val startMonth: Int = 1,
    val openingCashBalance: Double = 5000.0,
    val openingBankBalance: Double = 50000.0,
    val bankName: String = "ইসলামী ব্যাংক বাংলাদেশ পিএলসি",
    val bankAccountNo: String = "২০৫০১২৩৪৫৬৭৮৯",
    val isLateFeeEnabled: Boolean = false,
    val lateFeeAmount: Double = 0.0,
    val contactPhone: String = "০১৮১২-৩৪৫৬৭৮",
    val adminMasterPassword: String = "admin123",
    val masterAdminEmail: String = "raihanulislam296@gmail.com"
)
