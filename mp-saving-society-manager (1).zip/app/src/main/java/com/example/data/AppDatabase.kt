package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AuditDao
import com.example.data.dao.BankDao
import com.example.data.dao.ExpenseDao
import com.example.data.dao.MemberDao
import com.example.data.dao.NoticeDao
import com.example.data.dao.SavingsDao
import com.example.data.dao.SettingsDao
import com.example.data.model.AuditLogEntity
import com.example.data.model.BankTransactionEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.MemberEntity
import com.example.data.model.NoticeEntity
import com.example.data.model.PaymentAllocationEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        MemberEntity::class,
        SavingsTransactionEntity::class,
        PaymentAllocationEntity::class,
        ExpenseEntity::class,
        BankTransactionEntity::class,
        NoticeEntity::class,
        AuditLogEntity::class,
        SocietySettingsEntity::class,
        com.example.data.model.AdminUserEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun memberDao(): MemberDao
    abstract fun savingsDao(): SavingsDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun bankDao(): BankDao
    abstract fun noticeDao(): NoticeDao
    abstract fun auditDao(): AuditDao
    abstract fun settingsDao(): SettingsDao
    abstract fun adminUserDao(): com.example.data.dao.AdminUserDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mp_saving_society.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(database: AppDatabase) {
            val settingsDao = database.settingsDao()
            val memberDao = database.memberDao()
            val savingsDao = database.savingsDao()
            val noticeDao = database.noticeDao()
            val auditDao = database.auditDao()
            val expenseDao = database.expenseDao()
            val bankDao = database.bankDao()
            val adminUserDao = database.adminUserDao()

            // 1. Initial Society Settings
            settingsDao.insertOrUpdateSettings(
                SocietySettingsEntity(
                    id = 1,
                    societyNameBn = "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
                    societyNameEn = "MP Saving Society",
                    location = "বাঁশখালী, চট্টগ্রাম, বাংলাদেশ",
                    monthlySavingsAmount = 500.0,
                    startYear = 2026,
                    startMonth = 1,
                    openingCashBalance = 4500.0,
                    openingBankBalance = 35000.0,
                    bankName = "ইসলামী ব্যাংক বাংলাদেশ পিএলসি (বাঁশখালী শাখা)",
                    bankAccountNo = "২০৫০২৮৭৬৫০১২৩৪৫",
                    contactPhone = "০১৮১৫-৯৮৭৬৫৪",
                    adminMasterPassword = "admin123",
                    masterAdminEmail = "raihanulislam296@gmail.com"
                )
            )

            // Master Administrator Account (You)
            adminUserDao.insertAdmin(
                com.example.data.model.AdminUserEntity(
                    id = 1,
                    name = "মাস্টার সুপার এডমিন",
                    email = "raihanulislam296@gmail.com",
                    phone = "01815987654",
                    passwordHash = "admin123",
                    roleTitleBn = "মাস্টার সুপার এডমিন",
                    roleKey = "SUPER_ADMIN",
                    status = "ACTIVE",
                    isMaster = true
                )
            )

            // 2. Initial Founding Members
            val m1 = MemberEntity(
                id = 1,
                memberNumber = "MP-001",
                bengaliName = "মোহাম্মদ রফিকুল ইসলাম",
                englishName = "Md. Rafiqul Islam",
                mobileNumber = "01812345671",
                address = "মৌলভী পাড়া, বাঁশখালী, চট্টগ্রাম",
                joinDate = "2026-01-01",
                status = "ACTIVE",
                linkedPin = "1111",
                role = "ADMIN",
                notes = "প্রতিষ্ঠাতা সভাপতি ও সদস্য"
            )
            val m2 = MemberEntity(
                id = 2,
                memberNumber = "MP-002",
                bengaliName = "আব্দুল করিম চৌধুরী",
                englishName = "Abdul Karim Chowdhury",
                mobileNumber = "01812345672",
                address = "পূর্ব মৌলভী পাড়া, বাঁশখালী, চট্টগ্রাম",
                joinDate = "2026-01-01",
                status = "ACTIVE",
                linkedPin = "2222",
                role = "MEMBER",
                notes = "কোষাধ্যক্ষ"
            )
            val m3 = MemberEntity(
                id = 3,
                memberNumber = "MP-003",
                bengaliName = "মাওলানা জহিরুল হক",
                englishName = "Mawlana Jahirul Haque",
                mobileNumber = "01812345673",
                address = "মৌলভী পাড়া জামে মসজিদ রোড, বাঁশখালী",
                joinDate = "2026-01-01",
                status = "ACTIVE",
                linkedPin = "3333",
                role = "MEMBER",
                notes = "ধর্মীয় বিষয়ক সম্পাদক"
            )
            val m4 = MemberEntity(
                id = 4,
                memberNumber = "MP-004",
                bengaliName = "নুরুল আবছার",
                englishName = "Nurul Absar",
                mobileNumber = "01812345674",
                address = "পশ্চিম মৌলভী পাড়া, বাঁশখালী",
                joinDate = "2026-01-01",
                status = "ACTIVE",
                linkedPin = "4444",
                role = "MEMBER",
                notes = "সদস্য"
            )
            val m5 = MemberEntity(
                id = 5,
                memberNumber = "MP-005",
                bengaliName = "মোহাম্মদ সাজ্জাদ হোসেন",
                englishName = "Md. Sajjad Hossain",
                mobileNumber = "01812345675",
                address = "মৌলভী পাড়া, বাঁশখালী",
                joinDate = "2026-02-01",
                status = "ACTIVE",
                linkedPin = "5555",
                role = "MEMBER",
                notes = "নতুন সদস্য"
            )

            memberDao.insertMember(m1)
            memberDao.insertMember(m2)
            memberDao.insertMember(m3)
            memberDao.insertMember(m4)
            memberDao.insertMember(m5)

            // 3. Initial Sample Deposits with Receipt Numbers
            val t1 = SavingsTransactionEntity(
                id = 1,
                transactionId = "TXN-202610-001",
                receiptNumber = "RCP-202610-001",
                memberId = 1,
                month = 10,
                year = 2026,
                amount = 500.0,
                paymentDate = "2026-10-05",
                paymentMethod = "CASH",
                recordedBy = "সুপার এডমিন (রফিকুল ইসলাম)",
                note = "অক্টোবর ২০২৬ মাসের নিয়মিত সঞ্চয়"
            )
            val t2 = SavingsTransactionEntity(
                id = 2,
                transactionId = "TXN-202610-002",
                receiptNumber = "RCP-202610-002",
                memberId = 2,
                month = 10,
                year = 2026,
                amount = 500.0,
                paymentDate = "2026-10-08",
                paymentMethod = "BKASH",
                recordedBy = "সুপার এডমিন (রফিকুল ইসলাম)",
                note = "বিকাশের মাধ্যমে পরিশোধ"
            )
            val t3 = SavingsTransactionEntity(
                id = 3,
                transactionId = "TXN-202609-003",
                receiptNumber = "RCP-202609-003",
                memberId = 3,
                month = 9,
                year = 2026,
                amount = 500.0,
                paymentDate = "2026-09-12",
                paymentMethod = "CASH",
                recordedBy = "সুপার এডমিন",
                note = "সেপ্টেম্বর ২০২৬ নিয়মিত সঞ্চয়"
            )

            savingsDao.insertTransaction(t1)
            savingsDao.insertTransaction(t2)
            savingsDao.insertTransaction(t3)

            savingsDao.insertAllocations(
                listOf(
                    PaymentAllocationEntity(1, 1, 1, 10, 2026, 500.0),
                    PaymentAllocationEntity(2, 2, 2, 10, 2026, 500.0),
                    PaymentAllocationEntity(3, 3, 3, 9, 2026, 500.0)
                )
            )

            // 4. Initial Expenses
            expenseDao.insertExpense(
                ExpenseEntity(
                    id = 1,
                    date = "2026-10-02",
                    category = "OFFICE",
                    amount = 350.0,
                    description = "সদস্য রেজিস্টার খাতা ও রসিদ বই মুদ্রণ",
                    voucherRef = "VOUCHER-01",
                    recordedBy = "সুপার এডমিন"
                )
            )
            expenseDao.insertExpense(
                ExpenseEntity(
                    id = 2,
                    date = "2026-09-15",
                    category = "MEETING",
                    amount = 450.0,
                    description = "মাসিক সাধারণ সভার আপ্যায়ন খরচ",
                    voucherRef = "VOUCHER-02",
                    recordedBy = "সুপার এডমিন"
                )
            )

            // 5. Initial Bank Transactions
            bankDao.insertBankTransaction(
                BankTransactionEntity(
                    id = 1,
                    date = "2026-10-10",
                    type = "DEPOSIT",
                    amount = 5000.0,
                    bankName = "ইসলামী ব্যাংক বাংলাদেশ পিএলসি",
                    accountNo = "২০৫০২৮৭৬৫০১২৩৪৫",
                    reference = "SLIP-89102",
                    description = "অক্টোবর মাসের সঞ্চয় নগদ তহবিল হতে ব্যাংক অ্যাকাউন্টে জমা",
                    recordedBy = "সুপার এডমিন"
                )
            )

            // 6. Initial Notices
            noticeDao.insertNotice(
                NoticeEntity(
                    id = 1,
                    title = "অক্টোবর মাসের সঞ্চয় জমা প্রদান সংক্রান্ত নোটিশ",
                    content = "সম্মানিত সদস্যবৃন্দ, অক্টোবর ২০২৬ মাসের মাসিক সঞ্চয় আগামী ২০ অক্টোবরের মধ্যে জমা দেওয়ার জন্য বিনীত অনুরোধ করা যাচ্ছে। নগদ অথবা সমিতির ব্যাংক/বিকাশ হিসাবে জমা দিতে পারেন।",
                    type = "SAVINGS_REMINDER",
                    publishDate = "2026-10-01",
                    priority = "HIGH"
                )
            )
            noticeDao.insertNotice(
                NoticeEntity(
                    id = 2,
                    title = "মাসিক সাধারণ সভা ও কল্যাণ তহবিল পর্যালোচনা",
                    content = "আগামী শুক্রবার বাদ আছর মৌলভী পাড়া জামে মসজিদ প্রাঙ্গণে সমিতির মাসিক সাধারণ সভা অনুষ্ঠিত হবে। সকল সদস্যের উপস্থিতি কামনা করছি।",
                    type = "MEETING",
                    publishDate = "2026-10-15",
                    priority = "URGENT"
                )
            )

            // 7. Initial Audit Log
            auditDao.insertLog(
                AuditLogEntity(
                    timestamp = System.currentTimeMillis() - 86400000L * 10,
                    actorName = "সিস্টেম ইনিশিয়ালাইজার",
                    actorRole = "SUPER_ADMIN",
                    action = "SYSTEM_INITIALIZED",
                    entityType = "DATABASE",
                    entityId = "INIT",
                    details = "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতির হিসাব ব্যবস্থা সফলভাবে চালু হয়েছে।"
                )
            )
        }
    }
}
