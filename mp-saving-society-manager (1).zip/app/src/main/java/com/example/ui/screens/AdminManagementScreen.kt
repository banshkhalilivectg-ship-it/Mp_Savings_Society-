package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AdminUserEntity
import com.example.domain.BengaliUtils
import com.example.ui.SocietyViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminManagementScreen(viewModel: SocietyViewModel) {
    val context = LocalContext.current
    val adminList by viewModel.allAdminUsers.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var showInviteDialog by remember { mutableStateOf(false) }
    var showChangeMasterPassDialog by remember { mutableStateOf(false) }
    var adminToDelete by remember { mutableStateOf<AdminUserEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showInviteDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("invite_admin_fab")
            ) {
                Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("এডমিন ইনভাইট", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF4F7F4))
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(GoldSecondary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF6B4A00))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "এডমিন ও এডিটর ভূমিকা ব্যবস্থাপনা",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                    Text(
                        text = "শুধুমাত্র অনুমোদিত পাসওয়ার্ডধারী অ্যাডমিনরাই হিসাব এডিট করতে পারবেন",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Master Admin Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = GoldSecondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "মাস্টার এডমিন অ্যাকাউন্ট (আপনি)",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GoldSecondary
                        ) {
                            Text(
                                text = "মালিকানা ও পূর্ণ নিয়ন্ত্রণ",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF3E2E00)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "লগইন ইমেইল: ${settings?.masterAdminEmail ?: "raihanulislam296@gmail.com"}",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp
                    )
                    Text(
                        text = "যোগাযোগ: ${settings?.contactPhone ?: "০১৮১৫-৯৮৭৬৫৪"}",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { showChangeMasterPassDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("change_master_pass_button")
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("মাস্টার পাসওয়ার্ড পরিবর্তন করুন", color = EmeraldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "অনুমোদিত এডমিন ও এডিটর তালিকা (${adminList.size} জন)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF181D19)
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 75.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(adminList) { admin ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (admin.isMaster) EmeraldPrimary else Color(0xFF0284C7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.AdminPanelSettings,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = admin.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            text = "${admin.email} • ${admin.phone}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (admin.status == "ACTIVE") Color(0xFFD4EEDF) else Color(0xFFFFDAD6)
                                ) {
                                    Text(
                                        text = if (admin.status == "ACTIVE") admin.roleTitleBn else "স্থগিত",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (admin.status == "ACTIVE") EmeraldPrimary else Color(0xFFBA1A1A)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "পাসওয়ার্ড: ${admin.passwordHash}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF6B4A00),
                                    fontWeight = FontWeight.SemiBold
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // Share Credentials Button
                                    OutlinedButton(
                                        onClick = {
                                            shareInvitationMessage(
                                                context = context,
                                                societyName = settings?.societyNameBn ?: "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
                                                admin = admin
                                            )
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ইনভাইট পাঠান", fontSize = 10.sp)
                                    }

                                    if (!admin.isMaster) {
                                        // Suspend / Activate toggle
                                        OutlinedButton(
                                            onClick = {
                                                val newStatus = if (admin.status == "ACTIVE") "SUSPENDED" else "ACTIVE"
                                                viewModel.updateAdminStatus(admin, newStatus)
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text(if (admin.status == "ACTIVE") "স্থগিত" else "সক্রিয়", fontSize = 10.sp)
                                        }

                                        // Delete Button
                                        IconButton(
                                            onClick = { adminToDelete = admin },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "মুছুন",
                                                tint = Color(0xFFDC2626),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showInviteDialog) {
        InviteAdminDialog(
            onDismiss = { showInviteDialog = false },
            onSave = { name, email, phone, roleBn, roleKey, pass ->
                viewModel.inviteAdmin(name, email, phone, roleBn, roleKey, pass) {
                    showInviteDialog = false
                }
            }
        )
    }

    if (showChangeMasterPassDialog) {
        ChangeMasterPasswordDialog(
            onDismiss = { showChangeMasterPassDialog = false },
            onSave = { oldP, newP, callback ->
                viewModel.changeMasterPassword(oldP, newP, callback)
            }
        )
    }

    adminToDelete?.let { admin ->
        AlertDialog(
            onDismissRequest = { adminToDelete = null },
            title = { Text("এডমিন অ্যাক্সেস প্রত্যাহার করবেন?") },
            text = { Text("${admin.name} (${admin.email}) এর এডমিন অনুমতি সম্পূর্ণ ডিলিট করা হবে। তিনি আর এডমিন প্যানেলে লগইন করতে পারবেন না।") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAdmin(admin.id)
                        adminToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("হ্যাঁ, ডিলিট করুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { adminToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

private fun shareInvitationMessage(context: Context, societyName: String, admin: AdminUserEntity) {
    val message = """
        আসসালামু আলাইকুম ${admin.name},
        আপনাকে '$societyName'-এর এডমিন প্যানেলে '${admin.roleTitleBn}' হিসেবে দায়িত্ব প্রদান করা হয়েছে।

        📌 লগইন তথ্য:
        লগইন ইমেইল: ${admin.email}
        এডমিন পাসওয়ার্ড: ${admin.passwordHash}

        অ্যাপটি আপনার অ্যান্ড্রয়েড ফোনে ইনস্টল করে 'সুপার এডমিন' ট্যাবে গিয়ে উপরের ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করুন।
        (গোপনীয়তা রক্ষা করতে লগইন করার পর পাসওয়ার্ড পরিবর্তন করে নিতে পারেন।)
    """.trimIndent()

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
        putExtra(Intent.EXTRA_SUBJECT, "$societyName - এডমিন আমন্ত্রণপত্র")
    }
    context.startActivity(Intent.createChooser(intent, "এডমিন আমন্ত্রণপত্র পাঠান"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InviteAdminDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, email: String, phone: String, roleBn: String, roleKey: String, pass: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var roleKey by remember { mutableStateOf("ASSISTANT_ADMIN") }
    var roleBn by remember { mutableStateOf("সহকারী এডমিন") }
    var password by remember { mutableStateOf("Pass" + (1000..9999).random().toString()) }
    var isRoleExpanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val roles = listOf(
        Pair("ASSISTANT_ADMIN", "সহকারী এডমিন"),
        Pair("TREASURER", "কোষাধ্যক্ষ (জমা ও হিসাব রক্ষক)"),
        Pair("EDITOR", "হিসাব নিরীক্ষক / এডিটর"),
        Pair("SUPER_ADMIN", "যৌথ সুপার এডমিন")
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 20.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "নতুন এডমিন বা এডিটর আমন্ত্রণ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "বন্ধ")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("এডমিনের পূর্ণ নাম *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("জিমেইল / ইমেইল ঠিকানা * (যেমন: user@gmail.com)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("মোবাইল নম্বর") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                ExposedDropdownMenuBox(
                    expanded = isRoleExpanded,
                    onExpandedChange = { isRoleExpanded = !isRoleExpanded }
                ) {
                    OutlinedTextField(
                        value = roleBn,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("দায়িত্ব ও ভূমিকা নির্বাচন *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isRoleExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = isRoleExpanded,
                        onDismissRequest = { isRoleExpanded = false }
                    ) {
                        roles.forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    roleKey = key
                                    roleBn = label
                                    isRoleExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("লগইন পাসওয়ার্ড *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (error != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = error ?: "", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                error = "এডমিনের নাম লিখুন"
                            } else if (email.isBlank() || !email.contains("@")) {
                                error = "সঠিক জিমেইল বা ইমেইল ঠিকানা দিন"
                            } else if (password.length < 4) {
                                error = "পাসওয়ার্ড অন্তত ৪ অক্ষরের হতে হবে"
                            } else {
                                onSave(name.trim(), email.trim(), phone.trim(), roleBn, roleKey, password.trim())
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("আমন্ত্রণ নিশ্চিত করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChangeMasterPasswordDialog(
    onDismiss: () -> Unit,
    onSave: (oldPass: String, newPass: String, callback: (Boolean, String) -> Unit) -> Unit
) {
    var oldPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(20.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "মাস্টার এডমিন পাসওয়ার্ড পরিবর্তন",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = oldPass,
                    onValueChange = { oldPass = it },
                    label = { Text("পুরাতন বর্তমান পাসওয়ার্ড") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = newPass,
                    onValueChange = { newPass = it },
                    label = { Text("নতুন শক্তিশালী পাসওয়ার্ড") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = confirmPass,
                    onValueChange = { confirmPass = it },
                    label = { Text("নতুন পাসওয়ার্ড পুনরায় লিখুন") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (feedback != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = feedback ?: "",
                        color = if (isError) MaterialTheme.colorScheme.error else EmeraldPrimary,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            if (newPass.length < 4) {
                                feedback = "নতুন পাসওয়ার্ড অন্তত ৪ অক্ষরের হতে হবে"
                                isError = true
                            } else if (newPass != confirmPass) {
                                feedback = "নতুন দুটি পাসওয়ার্ড মেলেনি"
                                isError = true
                            } else {
                                onSave(oldPass, newPass) { success, msg ->
                                    feedback = msg
                                    isError = !success
                                    if (success) {
                                        onDismiss()
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1.3f),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("সংরক্ষণ করুন")
                    }
                }
            }
        }
    }
}
