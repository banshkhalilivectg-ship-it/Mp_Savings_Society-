package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.domain.ArrearsCalculator
import com.example.domain.BengaliUtils
import com.example.ui.SocietyViewModel
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.StatementDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun MemberDetailScreen(
    member: MemberEntity,
    viewModel: SocietyViewModel
) {
    val settings by viewModel.settings.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val allocations by viewModel.allAllocations.collectAsState()

    var showStatementDialog by remember { mutableStateOf(false) }
    var selectedTxForReceipt by remember { mutableStateOf<SavingsTransactionEntity?>(null) }

    val memberSummary = remember(member, settings, allocations, transactions) {
        ArrearsCalculator.calculateForMember(
            member = member,
            settings = settings ?: com.example.data.model.SocietySettingsEntity(),
            allocations = allocations,
            transactions = transactions
        )
    }

    val memberTransactions = remember(transactions, member) {
        transactions.filter { it.memberId == member.id }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4)),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Profile Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(EmeraldPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = member.memberNumber.replace("MP-", "#"),
                                fontWeight = FontWeight.Bold,
                                color = GoldSecondary,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = member.bengaliName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF181D19)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFD4EEDF)
                                ) {
                                    Text(
                                        text = member.memberNumber,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldPrimary
                                    )
                                }
                            }
                            if (member.englishName.isNotBlank()) {
                                Text(
                                    text = member.englishName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (member.status == "ACTIVE") Color(0xFFD4EEDF) else Color(0xFFFEF3C7)
                            ) {
                                Text(
                                    text = "স্থিতি: ${BengaliUtils.getStatusLabelBn(member.status)}",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (member.status == "ACTIVE") Color(0xFF042B1A) else Color(0xFF92400E)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "মোবাইল: ${member.mobileNumber}", fontSize = 12.sp, color = Color(0xFF424943))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Home, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "ঠিকানা: ${member.address}", fontSize = 12.sp, color = Color(0xFF424943))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "যোগদান: ${BengaliUtils.formatBengaliDate(member.joinDate)}",
                            fontSize = 12.sp,
                            color = Color(0xFF424943)
                        )
                    }

                    if (!member.notes.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "নোট: ${member.notes}",
                            fontSize = 11.sp,
                            color = Color(0xFF6B4A00),
                            modifier = Modifier
                                .background(Color(0xFFFBEBC7), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Arrears & Savings Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD4EEDF)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "মোট পরিশোধিত", fontSize = 11.sp, color = Color(0xFF042B1A))
                        Text(
                            text = BengaliUtils.formatTaka(memberSummary.totalPaid),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF042B1A)
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(
                        containerColor = if (memberSummary.totalArrears > 0) Color(0xFFFFDAD6) else Color(0xFFE9F1EB)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "অবশিষ্ট বকেয়া",
                            fontSize = 11.sp,
                            color = if (memberSummary.totalArrears > 0) Color(0xFFBA1A1A) else Color(0xFF181D19)
                        )
                        Text(
                            text = BengaliUtils.formatTaka(memberSummary.totalArrears),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (memberSummary.totalArrears > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A)
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFBEBC7)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "বকেয়া মাস", fontSize = 11.sp, color = Color(0xFF6B4A00))
                        Text(
                            text = "${BengaliUtils.toBengaliDigits(memberSummary.unpaidMonthsCount)} মাস",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF6B4A00)
                        )
                    }
                }
            }
        }

        // Button to Open Member Statement
        item {
            Button(
                onClick = { showStatementDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("view_statement_button"),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("পূর্ণাঙ্গ ব্যক্তিগত সঞ্চয় বিবরণী (Statement PDF)", fontWeight = FontWeight.Bold)
            }
        }

        // Month-by-Month Payment Ledger Header
        item {
            Text(
                text = "চলতি অর্থবছর মাসভিত্তিক স্থিতি (২০২৬)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF181D19),
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(memberSummary.monthlyItems) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(0.5.dp, Color(0xFFE5E9E5))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${item.monthNameBn} ${BengaliUtils.toBengaliDigits(item.year)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "নির্ধারিত: ${BengaliUtils.formatTaka(item.dueAmount)} • জমা: ${BengaliUtils.formatTaka(item.paidAmount)}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        if (item.paymentDate != null) {
                            Text(
                                text = "পরিশোধ: ${BengaliUtils.toBengaliDigits(item.paymentDate)} (রসিদ: ${item.receiptNumber})",
                                fontSize = 10.sp,
                                color = EmeraldPrimary
                            )
                        }
                    }

                    StatusBadge(status = item.status, label = item.statusLabelBn)
                }
            }
        }

        // Member Deposits History
        if (memberTransactions.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "পরিশোধিত জমার ইতিহাস ও রসিদসমূহ",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF181D19)
                )
            }

            items(memberTransactions) { tx ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedTxForReceipt = tx },
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Receipt, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = tx.receiptNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = "${BengaliUtils.getBengaliMonthName(tx.month)} • ${BengaliUtils.getPaymentMethodBn(tx.paymentMethod)}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = BengaliUtils.formatTaka(tx.amount), fontWeight = FontWeight.Bold, color = EmeraldPrimary, fontSize = 13.sp)
                            Text(text = "রসিদ দেখুন >", fontSize = 10.sp, color = Color(0xFF0284C7), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }

    if (showStatementDialog && settings != null) {
        StatementDialog(
            member = member,
            summary = memberSummary,
            settings = settings!!,
            onDismiss = { showStatementDialog = false }
        )
    }

    selectedTxForReceipt?.let { tx ->
        if (settings != null) {
            ReceiptDialog(
                transaction = tx,
                member = member,
                settings = settings!!,
                arrearsAfterTx = memberSummary.totalArrears,
                onDismiss = { selectedTxForReceipt = null }
            )
        }
    }
}
