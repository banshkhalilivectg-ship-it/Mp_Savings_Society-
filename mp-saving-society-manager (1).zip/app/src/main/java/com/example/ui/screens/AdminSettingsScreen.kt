package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SocietySettingsEntity
import com.example.ui.ScreenDestination
import com.example.ui.SocietyViewModel
import com.example.ui.theme.EmeraldPrimary

@Composable
fun AdminSettingsScreen(viewModel: SocietyViewModel) {
    val currentSettings by viewModel.settings.collectAsState()
    val sett = currentSettings ?: SocietySettingsEntity()

    var societyNameBn by remember(sett) { mutableStateOf(sett.societyNameBn) }
    var societyNameEn by remember(sett) { mutableStateOf(sett.societyNameEn) }
    var location by remember(sett) { mutableStateOf(sett.location) }
    var monthlySavingsAmount by remember(sett) { mutableStateOf(sett.monthlySavingsAmount.toInt().toString()) }
    var bankName by remember(sett) { mutableStateOf(sett.bankName) }
    var bankAccountNo by remember(sett) { mutableStateOf(sett.bankAccountNo) }
    var contactPhone by remember(sett) { mutableStateOf(sett.contactPhone) }

    var saveSuccessMessage by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4))
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = EmeraldPrimary
                    )
                    Spacer(modifier = Modifier.padding(start = 8.dp))
                    Text(
                        text = "সমিতির নিয়ম ও হিসাব কনফিগারেশন",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "সংস্থার নাম (বাংলায়) *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = societyNameBn,
                    onValueChange = { societyNameBn = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "ইংরেজি নাম", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = societyNameEn,
                    onValueChange = { societyNameEn = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "সমিতির অবস্থান / ঠিকানা", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Monthly Savings Amount Setting
                Text(
                    text = "মাসিক নির্ধারিত সঞ্চয় কিস্তি (টাকা) *",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = monthlySavingsAmount,
                    onValueChange = { monthlySavingsAmount = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setting_monthly_savings_input"),
                    singleLine = true,
                    leadingIcon = { Text("৳", fontWeight = FontWeight.Bold, color = EmeraldPrimary) }
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(text = "ব্যাংক বিবরণী", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = bankName,
                    onValueChange = { bankName = it },
                    label = { Text("ব্যাংকের নাম ও শাখা") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bankAccountNo,
                    onValueChange = { bankAccountNo = it },
                    label = { Text("ব্যাংক হিসাব নম্বর") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = contactPhone,
                    onValueChange = { contactPhone = it },
                    label = { Text("সমিতির অফিসিয়াল হেল্পলাইন নম্বর") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (saveSuccessMessage) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "✓ সেটিংস সফলভাবে সংরক্ষিত ও আপডেট হয়েছে।",
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val amount = monthlySavingsAmount.toDoubleOrNull() ?: 500.0
                        val updated = sett.copy(
                            societyNameBn = societyNameBn.trim(),
                            societyNameEn = societyNameEn.trim(),
                            location = location.trim(),
                            monthlySavingsAmount = amount,
                            bankName = bankName.trim(),
                            bankAccountNo = bankAccountNo.trim(),
                            contactPhone = contactPhone.trim()
                        )
                        viewModel.updateSettings(updated)
                        saveSuccessMessage = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_settings_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.padding(start = 8.dp))
                    Text("সেটিংস সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.ADMIN_MANAGEMENT) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("এডমিন ও এডিটর অনুমোদন ব্যবস্থাপনা >", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
