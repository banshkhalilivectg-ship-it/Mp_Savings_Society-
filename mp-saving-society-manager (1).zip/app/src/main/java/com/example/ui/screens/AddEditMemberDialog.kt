package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MemberEntity
import com.example.domain.BengaliUtils
import com.example.ui.theme.EmeraldPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMemberDialog(
    existingMember: MemberEntity? = null,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        bengaliName: String,
        englishName: String,
        memberNumber: String,
        mobileNumber: String,
        address: String,
        joinDate: String,
        status: String,
        notes: String?,
        linkedPin: String
    ) -> Unit
) {
    var bengaliName by remember { mutableStateOf(existingMember?.bengaliName ?: "") }
    var englishName by remember { mutableStateOf(existingMember?.englishName ?: "") }
    var memberNumber by remember { mutableStateOf(existingMember?.memberNumber ?: "") }
    var mobileNumber by remember { mutableStateOf(existingMember?.mobileNumber ?: "") }
    var address by remember { mutableStateOf(existingMember?.address ?: "মৌলভী পাড়া, বাঁশখালী, চট্টগ্রাম") }
    var joinDate by remember { mutableStateOf(existingMember?.joinDate ?: BengaliUtils.getCurrentDateIso()) }
    var status by remember { mutableStateOf(existingMember?.status ?: "ACTIVE") }
    var notes by remember { mutableStateOf(existingMember?.notes ?: "") }
    var linkedPin by remember { mutableStateOf(existingMember?.linkedPin ?: "1234") }
    var isStatusExpanded by remember { mutableStateOf(false) }

    var validationError by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 20.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (existingMember == null) "নতুন সদস্য নিবন্ধন" else "সদস্য তথ্য সম্পাদনা",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "বন্ধ")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = bengaliName,
                    onValueChange = { bengaliName = it },
                    label = { Text("পূর্ণ নাম (বাংলায়) *") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("member_bengali_name_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = englishName,
                    onValueChange = { englishName = it },
                    label = { Text("নাম (ইংরেজি)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = memberNumber,
                        onValueChange = { memberNumber = it },
                        label = { Text("সদস্য নং (যেমন: MP-006)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("member_number_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { mobileNumber = it },
                        label = { Text("মোবাইল নম্বর *") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("member_mobile_input"),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("ঠিকানা") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = joinDate,
                        onValueChange = { joinDate = it },
                        label = { Text("যোগদানের তারিখ (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    ExposedDropdownMenuBox(
                        expanded = isStatusExpanded,
                        onExpandedChange = { isStatusExpanded = !isStatusExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = BengaliUtils.getStatusLabelBn(status),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("সদস্যপদ স্থিতি") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStatusExpanded) },
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = isStatusExpanded,
                            onDismissRequest = { isStatusExpanded = false }
                        ) {
                            listOf("ACTIVE" to "সক্রিয়", "SUSPENDED" to "স্থগিত", "ARCHIVED" to "আর্কাইভ").forEach { pair ->
                                DropdownMenuItem(
                                    text = { Text(pair.second) },
                                    onClick = {
                                        status = pair.first
                                        isStatusExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = linkedPin,
                    onValueChange = { linkedPin = it },
                    label = { Text("সদস্য লগইন গোপন পিন (ডিফল্ট: 1234)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("প্রশাসনিক বিশেষ নোট (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                if (validationError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = validationError ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            if (bengaliName.isBlank()) {
                                validationError = "দয়া করে সদস্যের পূর্ণ বাংলা নাম লিখুন"
                            } else if (mobileNumber.isBlank()) {
                                validationError = "মোবাইল নম্বর প্রদান আবশ্যক"
                            } else {
                                onSave(
                                    existingMember?.id ?: 0L,
                                    bengaliName.trim(),
                                    englishName.trim(),
                                    memberNumber.trim(),
                                    mobileNumber.trim(),
                                    address.trim(),
                                    joinDate.trim(),
                                    status,
                                    notes.trim().ifEmpty { null },
                                    linkedPin.trim().ifEmpty { "1234" }
                                )
                                onDismiss()
                            }
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("save_member_confirm_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
