package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SavingsTransactionEntity
import com.example.domain.BengaliUtils
import com.example.ui.ScreenDestination
import com.example.ui.SocietyViewModel
import com.example.ui.components.MetricStatCard
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.SocietyHeroBanner
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun AdminDashboardScreen(viewModel: SocietyViewModel) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val members by viewModel.allMembers.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val notices by viewModel.publishedNotices.collectAsState()

    var selectedTxForReceipt by remember { mutableStateOf<SavingsTransactionEntity?>(null) }
    val membersMap = remember(members) { members.associateBy { it.id } }

    val recentTransactions = remember(transactions) {
        transactions.take(5)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4)),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Hero Branding Banner
        item {
            SocietyHeroBanner(
                societyNameBn = settings?.societyNameBn ?: "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
                societyNameEn = settings?.societyNameEn ?: "MP Saving Society",
                location = settings?.location ?: "বাঁশখালী, চট্টগ্রাম, বাংলাদেশ"
            )
        }

        // Financial Metrics Grid
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text(
                    text = "আর্থিক পর্যালোচনা ও মূল সূচক",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF181D19)
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Primary 2 Big Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = "মোট সংগৃহীত সঞ্চয়",
                        value = BengaliUtils.formatTaka(metrics.totalSavingsCollected),
                        icon = Icons.Default.Payments,
                        containerColor = EmeraldPrimary,
                        contentColor = Color.White,
                        modifier = Modifier.weight(1f),
                        subtitle = "সকল সদস্যের সঞ্চিত তহবিল"
                    )

                    MetricStatCard(
                        title = "চলতি মাস আদায়",
                        value = BengaliUtils.formatTaka(metrics.currentMonthCollection),
                        icon = Icons.Default.Receipt,
                        containerColor = GoldSecondary,
                        contentColor = Color(0xFF3E2E00),
                        modifier = Modifier.weight(1f),
                        subtitle = "অক্টোবর ২০২৬"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Secondary 4 Cards Row/Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricStatCard(
                        title = "মোট বকেয়া",
                        value = BengaliUtils.formatTaka(metrics.totalArrears),
                        icon = Icons.Default.Warning,
                        containerColor = if (metrics.totalArrears > 0) Color(0xFFFFDAD6) else Color(0xFFE9F1EB),
                        contentColor = if (metrics.totalArrears > 0) Color(0xFFBA1A1A) else Color(0xFF042B1A),
                        modifier = Modifier.weight(1f),
                        subtitle = "${BengaliUtils.toBengaliDigits(metrics.overdueMembersCount)} জন সদস্য"
                    )

                    MetricStatCard(
                        title = "সক্রিয় সদস্য",
                        value = "${BengaliUtils.toBengaliDigits(metrics.activeMembersCount)} জন",
                        icon = Icons.Default.People,
                        containerColor = Color(0xFFD4EEDF),
                        contentColor = Color(0xFF042B1A),
                        modifier = Modifier.weight(1f),
                        subtitle = "নিয়মিত সদস্য"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bank & Cash Balance Separated Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "নগদ ক্যাশ তহবিল", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(
                                text = BengaliUtils.formatTaka(metrics.cashInHand),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(36.dp)
                                .width(1.dp)
                                .background(Color(0xFFE0E5E0))
                        )

                        Column(modifier = Modifier.weight(1f).padding(start = 14.dp)) {
                            Text(text = "ব্যাংক ব্যালেন্স", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(
                                text = BengaliUtils.formatTaka(metrics.bankBalance),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0284C7)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(36.dp)
                                .width(1.dp)
                                .background(Color(0xFFE0E5E0))
                        )

                        Column(modifier = Modifier.weight(1f).padding(start = 14.dp)) {
                            Text(text = "মোট খরচ", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(
                                text = BengaliUtils.formatTaka(metrics.totalExpenses),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFDC2626)
                            )
                        }
                    }
                }
            }
        }

        // Quick Operations Menu
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(
                    text = "দ্রুত কার্যক্রম পরিচালনা",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF181D19)
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Monthly Collection Sheet Feature Card (Requested for WhatsApp Group & PDF)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(ScreenDestination.COLLECTION_SHEET) }
                        .testTag("action_collection_sheet"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF042B1A)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = GoldSecondary,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = null,
                                    tint = Color(0xFF3E2E00),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "মাসিক কালেকশন শিট",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = GoldSecondary
                                ) {
                                    Text(
                                        text = "হোয়াটসঅ্যাপ ও PDF",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF3E2E00),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "সকল সদস্যের নামের পাশে চলতি মাসের জমা ও বকেয়ার একনজরে তালিকা। গ্রুপে শেয়ার বা প্রিন্ট করুন।",
                                fontSize = 11.sp,
                                color = Color(0xFFD4EEDF),
                                lineHeight = 16.sp
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = GoldSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionTile(
                        title = "নতুন সঞ্চয় জমা",
                        subtitle = "রসিদ প্রদান",
                        icon = Icons.Default.AddCard,
                        color = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.SAVINGS_ENTRY)
                    }

                    QuickActionTile(
                        title = "সদস্য তালিকা",
                        subtitle = "পরিচালনা",
                        icon = Icons.Default.People,
                        color = Color(0xFF1B8755),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.MEMBER_DIRECTORY)
                    }

                    QuickActionTile(
                        title = "বকেয়া রিপোর্ট",
                        subtitle = "তাগাদা তালিকা",
                        icon = Icons.Default.Warning,
                        color = Color(0xFFD97706),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.ARREARS_REPORT)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionTile(
                        title = "খরচ হিসাব",
                        subtitle = "ভাউচার লিপিবদ্ধ",
                        icon = Icons.Default.MoneyOff,
                        color = Color(0xFFDC2626),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.EXPENSES)
                    }

                    QuickActionTile(
                        title = "ব্যাংক ও ক্যাশ",
                        subtitle = "জমা ও উত্তোলন",
                        icon = Icons.Default.AccountBalance,
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.BANK_RECORDS)
                    }

                    QuickActionTile(
                        title = "নোটিশ বোর্ড",
                        subtitle = "মিটিং ঘোষণা",
                        icon = Icons.Default.Campaign,
                        color = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.NOTICES)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionTile(
                        title = "অডিট লগ",
                        subtitle = "নিরাপত্তা ও নিরীক্ষা",
                        icon = Icons.Default.History,
                        color = Color(0xFF475569),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.AUDIT_LOG)
                    }

                    QuickActionTile(
                        title = "সেটিংস ও নিয়ম",
                        subtitle = "মাসিক কিস্তি",
                        icon = Icons.Default.Settings,
                        color = GoldSecondary,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.ADMIN_SETTINGS)
                    }

                    QuickActionTile(
                        title = "এডমিন ইনভাইট",
                        subtitle = "অনুমোদন নিয়ন্ত্রণ",
                        icon = Icons.Default.AdminPanelSettings,
                        color = Color(0xFF6B4A00),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.ADMIN_MANAGEMENT)
                    }

                    QuickActionTile(
                        title = "ক্লাউড গাইড",
                        subtitle = "ফায়ারবেস রুলস",
                        icon = Icons.Default.CloudDone,
                        color = Color(0xFF059669),
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.navigateTo(ScreenDestination.FIREBASE_SETUP)
                    }
                }
            }
        }

        // Recent Notices ticker if any
        if (notices.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text(
                        text = "সাম্প্রতিক ঘোষণা ও নোটিশ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFBEBC7)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        val notice = notices.first()
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = Color(0xFF92400E))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = notice.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF4A3700))
                                Text(text = notice.content, maxLines = 2, fontSize = 11.sp, color = Color(0xFF6B4A00))
                            }
                        }
                    }
                }
            }
        }

        // Recent Transactions Section
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "সাম্প্রতিক সঞ্চয় জমা লেনদেন",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                    Text(
                        text = "সকল দেখুন >",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            viewModel.navigateTo(ScreenDestination.TRANSACTION_HISTORY)
                        }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        if (recentTransactions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(text = "এখনো কোনো সঞ্চয় জমা রেকর্ড হয়নি।", color = Color.Gray)
                    }
                }
            }
        } else {
            items(recentTransactions) { tx ->
                val member = membersMap[tx.memberId]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable { selectedTxForReceipt = tx },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (tx.isReversed) Color(0xFFFFDAD6) else Color(0xFFD4EEDF)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (tx.isReversed) Icons.Default.TrendingDown else Icons.Default.Receipt,
                                    contentDescription = null,
                                    tint = if (tx.isReversed) Color(0xFFBA1A1A) else EmeraldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = member?.bengaliName ?: "সদস্য",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF181D19)
                                )
                                Text(
                                    text = "${member?.memberNumber ?: ""} • ${BengaliUtils.getBengaliMonthName(tx.month)}, ${BengaliUtils.toBengaliDigits(tx.year)}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = BengaliUtils.formatTaka(tx.amount),
                                fontWeight = FontWeight.Bold,
                                color = if (tx.isReversed) Color.Gray else EmeraldPrimary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (tx.isReversed) "বাতিলকৃত" else tx.receiptNumber,
                                fontSize = 10.sp,
                                color = if (tx.isReversed) Color(0xFFDC2626) else Color(0xFF6B4A00),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }

    // Receipt Modal when user taps on any transaction
    selectedTxForReceipt?.let { tx ->
        val member = membersMap[tx.memberId]
        if (member != null && settings != null) {
            ReceiptDialog(
                transaction = tx,
                member = member,
                settings = settings!!,
                arrearsAfterTx = 0.0,
                onDismiss = { selectedTxForReceipt = null }
            )
        }
    }
}

@Composable
private fun QuickActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF181D19),
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                fontSize = 10.sp,
                maxLines = 1
            )
        }
    }
}
