package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MP Saving Society Brand Palette: Forest Green, Gold, Crisp White
val EmeraldPrimary = Color(0xFF0D5C3A)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD4EEDF)
val EmeraldOnPrimaryContainer = Color(0xFF042B1A)

val GoldSecondary = Color(0xFFC59B27)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldSecondaryContainer = Color(0xFFFBEBC7)
val GoldOnSecondaryContainer = Color(0xFF3E2E00)

val LeafTertiary = Color(0xFF1B8755)
val LeafOnTertiary = Color(0xFFFFFFFF)
val LeafTertiaryContainer = Color(0xFFC2F0D4)
val LeafOnTertiaryContainer = Color(0xFF002111)

val BackgroundLight = Color(0xFFF4F7F4)
val OnBackgroundLight = Color(0xFF161D18)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF161D18)
val SurfaceVariantLight = Color(0xFFDEE5DD)
val OnSurfaceVariantLight = Color(0xFF424943)
val OutlineLight = Color(0xFF727972)

val EmeraldDark = Color(0xFF70DCA0)
val EmeraldOnDark = Color(0xFF00391F)
val EmeraldDarkContainer = Color(0xFF00522E)
val EmeraldOnDarkContainer = Color(0xFF8CF9BA)

val GoldDark = Color(0xFFF0C55A)
val GoldOnDark = Color(0xFF402D00)
val GoldDarkContainer = Color(0xFF5B4300)
val GoldOnDarkContainer = Color(0xFFFFDF9B)

val BackgroundDark = Color(0xFF0F1511)
val OnBackgroundDark = Color(0xFFE0E4DE)
val SurfaceDark = Color(0xFF121814)
val OnSurfaceDark = Color(0xFFE0E4DE)
val SurfaceVariantDark = Color(0xFF424943)
val OnSurfaceVariantDark = Color(0xFFC2C9C1)

val SuccessGreen = Color(0xFF198754)
val PendingOrange = Color(0xFFD97706)
val DangerRed = Color(0xFFDC2626)
val InfoBlue = Color(0xFF0284C7)
