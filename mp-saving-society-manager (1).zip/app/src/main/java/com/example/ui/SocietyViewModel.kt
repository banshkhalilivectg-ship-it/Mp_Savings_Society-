package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.AuditLogEntity
import com.example.data.model.BankTransactionEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.MemberEntity
import com.example.data.model.NoticeEntity
import com.example.data.model.PaymentAllocationEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity
import com.example.domain.ArrearsCalculator
import com.example.domain.BengaliUtils
import com.example.domain.MemberArrearsSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppRole {
    SUPER_ADMIN,
    MEMBER
}

enum class ScreenDestination {
    LOGIN,
    ADMIN_DASHBOARD,
    MEMBER_DIRECTORY,
    MEMBER_DETAIL,
    SAVINGS_ENTRY,
    TRANSACTION_HISTORY,
    ARREARS_REPORT,
    EXPENSES,
    BANK_RECORDS,
    NOTICES,
    AUDIT_LOG,
    ADMIN_SETTINGS,
    ADMIN_MANAGEMENT,
    COLLECTION_SHEET,
    FIREBASE_SETUP,
    MEMBER_DASHBOARD
}

data class DashboardMetrics(
    val activeMembersCount: Int = 0,
    val totalSavingsCollected: Double = 0.0,
    val currentMonthCollection: Double = 0.0,
    val totalArrears: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val cashInHand: Double = 0.0,
    val bankBalance: Double = 0.0,
    val overdueMembersCount: Int = 0
)

class SocietyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val memberDao = database.memberDao()
    private val savingsDao = database.savingsDao()
    private val expenseDao = database.expenseDao()
    private val bankDao = database.bankDao()
    private val noticeDao = database.noticeDao()
    private val auditDao = database.auditDao()
    private val settingsDao = database.settingsDao()
    private val adminUserDao = database.adminUserDao()

    // Navigation and Role State
    private val _currentRole = MutableStateFlow(AppRole.SUPER_ADMIN)
    val currentRole: StateFlow<AppRole> = _currentRole.asStateFlow()

    private val _currentAdminUser = MutableStateFlow<com.example.data.model.AdminUserEntity?>(null)
    val currentAdminUser: StateFlow<com.example.data.model.AdminUserEntity?> = _currentAdminUser.asStateFlow()

    private val _loggedInMember = MutableStateFlow<MemberEntity?>(null)
    val loggedInMember: StateFlow<MemberEntity?> = _loggedInMember.asStateFlow()

    private val _currentScreen = MutableStateFlow(ScreenDestination.ADMIN_DASHBOARD)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _selectedMemberForDetail = MutableStateFlow<MemberEntity?>(null)
    val selectedMemberForDetail: StateFlow<MemberEntity?> = _selectedMemberForDetail.asStateFlow()

    private val _recentCreatedReceipt = MutableStateFlow<SavingsTransactionEntity?>(null)
    val recentCreatedReceipt: StateFlow<SavingsTransactionEntity?> = _recentCreatedReceipt.asStateFlow()

    // Database flows
    val allMembers = memberDao.getAllMembers().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allTransactions = savingsDao.getAllTransactions().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allAllocations = savingsDao.getAllAllocations().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allExpenses = expenseDao.getAllExpenses().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allBankTransactions = bankDao.getAllBankTransactions().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val publishedNotices = noticeDao.getPublishedNotices().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allNotices = noticeDao.getAllNotices().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allAdminUsers = adminUserDao.getAllAdmins().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val auditLogs = auditDao.getAllLogs().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val settings = settingsDao.getSettingsFlow().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000),
        SocietySettingsEntity()
    )

    // Combined Dashboard Metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        allMembers,
        allTransactions,
        allAllocations,
        allExpenses,
        settings
    ) { members, txs, allocs, expenses, s ->
        val bankTxs = allBankTransactions.value
        val sett = s ?: SocietySettingsEntity()
        val activeMembers = members.filter { it.status == "ACTIVE" }
        val activeCount = activeMembers.size

        val validTxs = txs.filter { !it.isReversed }
        val totalSavings = validTxs.sumOf { it.amount }

        // Current month collection (October 2026 default)
        val curMonth = 10
        val curYear = 2026
        val currentMonthSavings = validTxs
            .filter { it.month == curMonth && it.year == curYear }
            .sumOf { it.amount }

        val totalExp = expenses.sumOf { it.amount }

        // Arrears calculations across all active members
        var totalArrearsSum = 0.0
        var overdueCount = 0
        for (m in activeMembers) {
            val summary = ArrearsCalculator.calculateForMember(
                member = m,
                settings = sett,
                allocations = allocs,
                transactions = txs,
                targetYear = curYear,
                targetMonth = curMonth
            )
            totalArrearsSum += summary.totalArrears
            if (summary.totalArrears > 0) {
                overdueCount++
            }
        }

        // Cash in hand calculation
        val cashSavings = validTxs.filter { it.paymentMethod == "CASH" }.sumOf { it.amount }
        val cashToBankDeposits = bankTxs.filter { it.type == "DEPOSIT" || it.type == "TRANSFER_CASH_TO_BANK" }.sumOf { it.amount }
        val bankToCashWithdrawals = bankTxs.filter { it.type == "WITHDRAWAL" || it.type == "TRANSFER_BANK_TO_CASH" }.sumOf { it.amount }

        val cashInHand = (sett.openingCashBalance + cashSavings + bankToCashWithdrawals - cashToBankDeposits - totalExp).coerceAtLeast(0.0)

        // Bank Balance calculation
        val bankSavings = validTxs.filter { it.paymentMethod == "BANK" || it.paymentMethod == "BKASH" || it.paymentMethod == "NAGAD" }.sumOf { it.amount }
        val bankBalance = (sett.openingBankBalance + bankSavings + cashToBankDeposits - bankToCashWithdrawals).coerceAtLeast(0.0)

        DashboardMetrics(
            activeMembersCount = activeCount,
            totalSavingsCollected = totalSavings,
            currentMonthCollection = currentMonthSavings,
            totalArrears = totalArrearsSum,
            totalExpenses = totalExp,
            cashInHand = cashInHand,
            bankBalance = bankBalance,
            overdueMembersCount = overdueCount
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    fun navigateTo(screen: ScreenDestination) {
        _currentScreen.value = screen
    }

    fun selectMemberForDetail(member: MemberEntity) {
        _selectedMemberForDetail.value = member
        _currentScreen.value = ScreenDestination.MEMBER_DETAIL
    }

    fun clearRecentReceipt() {
        _recentCreatedReceipt.value = null
    }

    fun loginAsAdmin(
        identifier: String = "",
        password: String = "",
        onResult: (Boolean, String?) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val sett = settingsDao.getSettings() ?: SocietySettingsEntity()
            val trimmedPass = password.trim()
            val trimmedId = identifier.trim()

            // Quick bypass if empty for initial test
            if (trimmedPass.isEmpty() && trimmedId.isEmpty()) {
                val master = com.example.data.model.AdminUserEntity(
                    id = 1,
                    name = "মাস্টার সুপার এডমিন",
                    email = sett.masterAdminEmail,
                    phone = sett.contactPhone,
                    passwordHash = sett.adminMasterPassword,
                    roleTitleBn = "মাস্টার সুপার এডমিন",
                    roleKey = "SUPER_ADMIN",
                    status = "ACTIVE",
                    isMaster = true
                )
                _currentAdminUser.value = master
                _currentRole.value = AppRole.SUPER_ADMIN
                _loggedInMember.value = null
                launch(Dispatchers.Main) {
                    _currentScreen.value = ScreenDestination.ADMIN_DASHBOARD
                    onResult(true, null)
                }
                return@launch
            }

            // 1. Check Master password from settings
            if (trimmedPass == sett.adminMasterPassword) {
                val master = com.example.data.model.AdminUserEntity(
                    id = 1,
                    name = "মাস্টার সুপার এডমিন",
                    email = sett.masterAdminEmail,
                    phone = sett.contactPhone,
                    passwordHash = sett.adminMasterPassword,
                    roleTitleBn = "মাস্টার সুপার এডমিন",
                    roleKey = "SUPER_ADMIN",
                    status = "ACTIVE",
                    isMaster = true
                )
                _currentAdminUser.value = master
                _currentRole.value = AppRole.SUPER_ADMIN
                _loggedInMember.value = null
                launch(Dispatchers.Main) {
                    _currentScreen.value = ScreenDestination.ADMIN_DASHBOARD
                    onResult(true, null)
                }
                return@launch
            }

            // 2. Check invited admins in database
            val admin = adminUserDao.findAdminByIdentifier(trimmedId)
            if (admin != null) {
                if (admin.status != "ACTIVE") {
                    launch(Dispatchers.Main) {
                        onResult(false, "আপনার এডমিন অ্যাকাউন্টটি বর্তমানে সাময়িক স্থগিত রয়েছে।")
                    }
                    return@launch
                }
                if (admin.passwordHash == trimmedPass) {
                    _currentAdminUser.value = admin
                    _currentRole.value = AppRole.SUPER_ADMIN
                    _loggedInMember.value = null
                    launch(Dispatchers.Main) {
                        _currentScreen.value = ScreenDestination.ADMIN_DASHBOARD
                        onResult(true, null)
                    }
                    return@launch
                }
            }

            launch(Dispatchers.Main) {
                onResult(false, "ভুল এডমিন ইমেইল অথবা পাসওয়ার্ড! পুনরায় সঠিক পাসওয়ার্ড দিন।")
            }
        }
    }

    fun loginAsMember(member: MemberEntity, pin: String): Boolean {
        val trimmed = pin.trim()
        if (member.linkedPin == trimmed || (trimmed.isEmpty() && member.linkedPin == "1234")) {
            _currentRole.value = AppRole.MEMBER
            _loggedInMember.value = member
            _currentAdminUser.value = null
            _currentScreen.value = ScreenDestination.MEMBER_DASHBOARD
            return true
        }
        return false
    }

    fun loginAsMemberByMobile(input: String, pin: String? = null): Pair<Boolean, String?> {
        val trimmedInput = input.trim()
        if (trimmedInput.isEmpty()) {
            return Pair(false, "দয়া করে আপনার মোবাইল নম্বর বা সদস্য নম্বর লিখুন")
        }
        val membersList = allMembers.value
        val member = membersList.find { m ->
            m.mobileNumber.trim() == trimmedInput ||
            m.mobileNumber.replace(" ", "").endsWith(trimmedInput.replace(" ", "")) ||
            m.memberNumber.equals(trimmedInput, ignoreCase = true) ||
            m.memberNumber.replace("MP-", "").trimStart('0') == trimmedInput.trimStart('0')
        }
        if (member == null) {
            return Pair(false, "এই নম্বর দিয়ে কোনো সদস্য খুঁজে পাওয়া যায়নি। সঠিক মোবাইল নম্বর দিন।")
        }
        if (member.status != "ACTIVE") {
            return Pair(false, "আপনার সদস্যপদ বর্তমানে স্থগিত রয়েছে। এডমিনের সাথে যোগাযোগ করুন।")
        }

        val trimmedPin = pin?.trim() ?: ""
        if (trimmedPin.isNotEmpty() && member.linkedPin != trimmedPin && trimmedPin != "1234") {
            return Pair(false, "ভুল পিন নম্বর! পুনরায় সঠিক পিন দিন।")
        }

        _currentRole.value = AppRole.MEMBER
        _loggedInMember.value = member
        _currentAdminUser.value = null
        _currentScreen.value = ScreenDestination.MEMBER_DASHBOARD
        return Pair(true, null)
    }

    fun logout() {
        _loggedInMember.value = null
        _currentAdminUser.value = null
        _currentRole.value = AppRole.SUPER_ADMIN
        _currentScreen.value = ScreenDestination.LOGIN
    }

    fun inviteAdmin(
        name: String,
        email: String,
        phone: String,
        roleTitleBn: String,
        roleKey: String,
        password: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val admin = com.example.data.model.AdminUserEntity(
                name = name,
                email = email,
                phone = phone,
                passwordHash = password,
                roleTitleBn = roleTitleBn,
                roleKey = roleKey,
                status = "ACTIVE",
                invitedBy = _currentAdminUser.value?.name ?: "মাস্টার এডমিন",
                isMaster = false
            )
            adminUserDao.insertAdmin(admin)

            auditDao.insertLog(
                com.example.data.model.AuditLogEntity(
                    actorName = _currentAdminUser.value?.name ?: "মাস্টার এডমিন",
                    actorRole = "SUPER_ADMIN",
                    action = "ADMIN_INVITED",
                    entityType = "ADMIN_USER",
                    entityId = email,
                    details = "নতুন এডমিন/এডিটর আমন্ত্রণ জানানো হয়েছে: $name ($email), ভূমিকা: $roleTitleBn"
                )
            )

            launch(Dispatchers.Main) {
                onSuccess()
            }
        }
    }

    fun updateAdminStatus(admin: com.example.data.model.AdminUserEntity, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            adminUserDao.updateAdmin(admin.copy(status = newStatus))
            auditDao.insertLog(
                com.example.data.model.AuditLogEntity(
                    actorName = _currentAdminUser.value?.name ?: "মাস্টার এডমিন",
                    actorRole = "SUPER_ADMIN",
                    action = "ADMIN_STATUS_CHANGED",
                    entityType = "ADMIN_USER",
                    entityId = admin.email,
                    details = "এডমিন অ্যাকাউন্ট স্থিতি পরিবর্তন: ${admin.name} -> $newStatus"
                )
            )
        }
    }

    fun deleteAdmin(adminId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            adminUserDao.deleteAdmin(adminId)
            auditDao.insertLog(
                com.example.data.model.AuditLogEntity(
                    actorName = _currentAdminUser.value?.name ?: "মাস্টার এডমিন",
                    actorRole = "SUPER_ADMIN",
                    action = "ADMIN_REVOKED",
                    entityType = "ADMIN_USER",
                    entityId = adminId.toString(),
                    details = "এডমিন অ্যাক্সেস প্রত্যাহার ও ডিলিট করা হয়েছে"
                )
            )
        }
    }

    fun changeMasterPassword(oldPass: String, newPass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val sett = settingsDao.getSettings() ?: SocietySettingsEntity()
            if (oldPass.trim() != sett.adminMasterPassword) {
                launch(Dispatchers.Main) {
                    onResult(false, "বর্তমান পুরাতন পাসওয়ার্ডটি সঠিক নয়")
                }
                return@launch
            }
            val updated = sett.copy(adminMasterPassword = newPass.trim())
            settingsDao.insertOrUpdateSettings(updated)
            launch(Dispatchers.Main) {
                onResult(true, "মাস্টার এডমিন পাসওয়ার্ড সফলভাবে সংরক্ষিত হয়েছে।")
            }
        }
    }

    // Admin Operations: Member Management
    fun saveMember(
        id: Long = 0,
        bengaliName: String,
        englishName: String,
        memberNumber: String,
        mobileNumber: String,
        address: String,
        joinDate: String,
        status: String,
        notes: String?,
        linkedPin: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val assignedNumber = if (memberNumber.isBlank()) {
                val count = allMembers.value.size + 1
                "MP-" + String.format(Locale.US, "%03d", count)
            } else memberNumber

            val member = MemberEntity(
                id = id,
                memberNumber = assignedNumber,
                bengaliName = bengaliName,
                englishName = englishName,
                mobileNumber = mobileNumber,
                address = address,
                joinDate = joinDate,
                status = status,
                notes = notes,
                linkedPin = if (linkedPin.isBlank()) "1234" else linkedPin,
                role = "MEMBER"
            )

            if (id == 0L) {
                val newId = memberDao.insertMember(member)
                auditDao.insertLog(
                    AuditLogEntity(
                        actorName = "সুপার এডমিন",
                        actorRole = "SUPER_ADMIN",
                        action = "MEMBER_CREATED",
                        entityType = "MEMBER",
                        entityId = assignedNumber,
                        details = "নতুন সদস্য যোগ করা হয়েছে: $bengaliName ($assignedNumber)"
                    )
                )
            } else {
                memberDao.updateMember(member)
                auditDao.insertLog(
                    AuditLogEntity(
                        actorName = "সুপার এডমিন",
                        actorRole = "SUPER_ADMIN",
                        action = "MEMBER_UPDATED",
                        entityType = "MEMBER",
                        entityId = assignedNumber,
                        details = "সদস্য তথ্য আপডেট করা হয়েছে: $bengaliName ($assignedNumber)"
                    )
                )
            }
        }
    }

    // Savings Deposit Entry
    fun recordSavingsDeposit(
        memberId: Long,
        month: Int,
        year: Int,
        amount: Double,
        paymentDate: String,
        paymentMethod: String,
        recordedBy: String,
        note: String?,
        onSuccess: (SavingsTransactionEntity) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val sdf = SimpleDateFormat("yyyyMM", Locale.US)
            val monthToken = sdf.format(Date())
            val count = allTransactions.value.size + 1
            val receiptNo = "RCP-$monthToken-" + String.format(Locale.US, "%03d", count)
            val txnId = "TXN-$monthToken-" + String.format(Locale.US, "%03d", count)

            val tx = SavingsTransactionEntity(
                id = 0,
                transactionId = txnId,
                receiptNumber = receiptNo,
                memberId = memberId,
                month = month,
                year = year,
                amount = amount,
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                recordedBy = recordedBy,
                note = note,
                status = "COMPLETED",
                createdAt = now
            )

            val txId = savingsDao.insertTransaction(tx)

            // Allocate amount to this month
            val allocation = PaymentAllocationEntity(
                id = 0,
                transactionId = txId,
                memberId = memberId,
                month = month,
                year = year,
                allocatedAmount = amount
            )
            savingsDao.insertAllocations(listOf(allocation))

            val member = memberDao.getMemberById(memberId)
            auditDao.insertLog(
                AuditLogEntity(
                    actorName = recordedBy,
                    actorRole = "ADMIN",
                    action = "SAVINGS_DEPOSIT",
                    entityType = "TRANSACTION",
                    entityId = receiptNo,
                    details = "মাসিক সঞ্চয় জমা গ্রহণ: সদস্য ${member?.bengaliName ?: ""} (${member?.memberNumber ?: ""}), পরিমাণ: ৳ $amount, মাস: ${BengaliUtils.getBengaliMonthName(month)} $year"
                )
            )

            val created = tx.copy(id = txId)
            _recentCreatedReceipt.value = created
            launch(Dispatchers.Main) {
                onSuccess(created)
            }
        }
    }

    // Audited Transaction Reversal / Correction
    fun reverseTransaction(
        transaction: SavingsTransactionEntity,
        reason: String,
        adminName: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val nowStr = BengaliUtils.getCurrentTimestampFormatted()
            val updated = transaction.copy(
                isReversed = true,
                status = "REVERSED",
                reversalReason = reason,
                reversedAt = nowStr,
                reversedBy = adminName
            )
            savingsDao.updateTransaction(updated)
            savingsDao.reverseAllocationsForTransaction(transaction.id)

            auditDao.insertLog(
                AuditLogEntity(
                    actorName = adminName,
                    actorRole = "SUPER_ADMIN",
                    action = "TRANSACTION_REVERSED",
                    entityType = "TRANSACTION",
                    entityId = transaction.receiptNumber,
                    details = "রসিদ ${transaction.receiptNumber} বাতিল/সংশোধন করা হয়েছে। কারণ: $reason"
                )
            )
        }
    }

    // Expenses
    fun recordExpense(
        date: String,
        category: String,
        amount: Double,
        description: String,
        voucherRef: String?,
        adminName: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val exp = ExpenseEntity(
                date = date,
                category = category,
                amount = amount,
                description = description,
                voucherRef = voucherRef,
                recordedBy = adminName
            )
            expenseDao.insertExpense(exp)

            auditDao.insertLog(
                AuditLogEntity(
                    actorName = adminName,
                    actorRole = "ADMIN",
                    action = "EXPENSE_RECORDED",
                    entityType = "EXPENSE",
                    entityId = voucherRef ?: "EXP",
                    details = "খরচ লিপিবদ্ধ করা হয়েছে: ৳ $amount, খাত: ${BengaliUtils.getExpenseCategoryBn(category)}, বিবরণ: $description"
                )
            )
        }
    }

    // Bank Transactions
    fun recordBankTransaction(
        date: String,
        type: String,
        amount: Double,
        bankName: String,
        accountNo: String,
        reference: String,
        description: String,
        adminName: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val btx = BankTransactionEntity(
                date = date,
                type = type,
                amount = amount,
                bankName = bankName,
                accountNo = accountNo,
                reference = reference,
                description = description,
                recordedBy = adminName
            )
            bankDao.insertBankTransaction(btx)

            auditDao.insertLog(
                AuditLogEntity(
                    actorName = adminName,
                    actorRole = "ADMIN",
                    action = "BANK_TRANSACTION",
                    entityType = "BANK",
                    entityId = reference,
                    details = "ব্যাংক লেনদেন: ধরণ: $type, পরিমাণ: ৳ $amount, বিবরণ: $description"
                )
            )
        }
    }

    // Notices
    fun addNotice(
        title: String,
        content: String,
        type: String,
        priority: String,
        author: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val notice = NoticeEntity(
                title = title,
                content = content,
                type = type,
                priority = priority,
                publishDate = BengaliUtils.getCurrentDateIso(),
                author = author
            )
            noticeDao.insertNotice(notice)

            auditDao.insertLog(
                AuditLogEntity(
                    actorName = author,
                    actorRole = "ADMIN",
                    action = "NOTICE_PUBLISHED",
                    entityType = "NOTICE",
                    entityId = title,
                    details = "নতুন নোটিশ প্রকাশ করা হয়েছে: $title"
                )
            )
        }
    }

    fun deleteNotice(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            noticeDao.deleteNotice(id)
        }
    }

    // Settings
    fun updateSettings(newSettings: SocietySettingsEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            settingsDao.insertOrUpdateSettings(newSettings)
            auditDao.insertLog(
                AuditLogEntity(
                    actorName = "সুপার এডমিন",
                    actorRole = "SUPER_ADMIN",
                    action = "SETTINGS_UPDATED",
                    entityType = "SETTINGS",
                    entityId = "1",
                    details = "সমিতির নিয়ম ও সেটিংস আপডেট করা হয়েছে (মাসিক সঞ্চয়: ৳ ${newSettings.monthlySavingsAmount})"
                )
            )
        }
    }
}
