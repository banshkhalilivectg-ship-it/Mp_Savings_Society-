package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SavingsTransactionEntity
import com.example.domain.BengaliUtils
import com.example.domain.PdfReportGenerator
import com.example.ui.SocietyViewModel
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.EmeraldPrimary

@Composable
fun TransactionHistoryScreen(viewModel: SocietyViewModel) {
    val context = LocalContext.current
    val transactions by viewModel.allTransactions.collectAsState()
    val members by viewModel.allMembers.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val membersMap = remember(members) { members.associateBy { it.id } }

    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, COMPLETED, REVERSED
    var selectedTxForReceipt by remember { mutableStateOf<SavingsTransactionEntity?>(null) }
    var transactionToReverse by remember { mutableStateOf<SavingsTransactionEntity?>(null) }
    var reversalReason by remember { mutableStateOf("") }

    val filteredList = remember(transactions, selectedFilter) {
        when (selectedFilter) {
            "COMPLETED" -> transactions.filter { !it.isReversed }
            "REVERSED" -> transactions.filter { it.isReversed }
            else -> transactions
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4))
            .padding(16.dp)
    ) {
        // Top Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "সঞ্চয় জমা লেজার ও লেনদেন ইতিহাস",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF181D19)
                )
                Text(
                    text = "সকল রসিদ ও নিরীক্ষিত লেনদেন বিবরণী",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            Button(
                onClick = {
                    val csvFile = PdfReportGenerator.exportTransactionsCsv(context, transactions, membersMap)
                    if (csvFile != null) {
                        PdfReportGenerator.sharePdfFile(context, csvFile, "লেনদেন CSV এক্সপোর্ট")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("export_csv_button")
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("CSV এক্সপোর্ট", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = selectedFilter == "ALL",
                onClick = { selectedFilter = "ALL" },
                label = { Text("সকল (${transactions.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = selectedFilter == "COMPLETED",
                onClick = { selectedFilter = "COMPLETED" },
                label = { Text("সফল জমা (${transactions.count { !it.isReversed }})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = selectedFilter == "REVERSED",
                onClick = { selectedFilter = "REVERSED" },
                label = { Text("বাতিল/সংশোধিত (${transactions.count { it.isReversed }})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFBA1A1A),
                    selectedLabelColor = Color.White
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "কোনো লেনদেন পাওয়া যায়নি।", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredList) { tx ->
                    val member = membersMap[tx.memberId]
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedTxForReceipt = tx }
                            .testTag("tx_item_${tx.receiptNumber}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(if (tx.isReversed) Color(0xFFFFDAD6) else Color(0xFFD4EEDF)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (tx.isReversed) Icons.Default.TrendingDown else Icons.Default.Receipt,
                                            contentDescription = null,
                                            tint = if (tx.isReversed) Color(0xFFBA1A1A) else EmeraldPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = member?.bengaliName ?: "অজ্ঞাত সদস্য",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "রসিদ: ${tx.receiptNumber} • ${member?.memberNumber ?: ""}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = BengaliUtils.formatTaka(tx.amount),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (tx.isReversed) Color.Gray else EmeraldPrimary
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (tx.isReversed) Color(0xFFFFDAD6) else Color(0xFFD4EEDF)
                                    ) {
                                        Text(
                                            text = if (tx.isReversed) "বাতিলকৃত" else "সফল",
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (tx.isReversed) Color(0xFFBA1A1A) else Color(0xFF042B1A)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "সঞ্চয় মাস: ${BengaliUtils.getBengaliMonthName(tx.month)}, ${BengaliUtils.toBengaliDigits(tx.year)} • ${BengaliUtils.getPaymentMethodBn(tx.paymentMethod)}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF424943)
                                )

                                if (!tx.isReversed) {
                                    OutlinedButton(
                                        onClick = {
                                            transactionToReverse = tx
                                            reversalReason = ""
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("বাতিল / সংশোধন", fontSize = 11.sp)
                                    }
                                }
                            }

                            if (tx.isReversed && !tx.reversalReason.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "বাতিলের কারণ: ${tx.reversalReason} (${tx.reversedAt ?: ""})",
                                    fontSize = 10.sp,
                                    color = Color(0xFFBA1A1A),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Controlled Reversal Dialog
    transactionToReverse?.let { tx ->
        AlertDialog(
            onDismissRequest = { transactionToReverse = null },
            title = {
                Text(
                    text = "লেনদেন বাতিল ও সংশোধন প্রক্রিয়া",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFBA1A1A)
                )
            },
            text = {
                Column {
                    Text(
                        text = "রসিদ নং: ${tx.receiptNumber}\nপরিমাণ: ৳ ${tx.amount}\n\nনিরীক্ষার স্বার্থে লেনদেন মোছা হবে না; এটি বাতিল চিহ্নিত হবে এবং অডিট লগে লিপিবদ্ধ থাকবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF424943)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reversalReason,
                        onValueChange = { reversalReason = it },
                        label = { Text("বাতিলকরণের সুনির্দিষ্ট কারণ লিখুন *") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reversalReason.isNotBlank()) {
                            viewModel.reverseTransaction(
                                transaction = tx,
                                reason = reversalReason.trim(),
                                adminName = "সুপার এডমিন"
                            )
                            transactionToReverse = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("নিশ্চিত বাতিল করুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { transactionToReverse = null }) {
                    Text("ফিরে যান")
                }
            }
        )
    }

    selectedTxForReceipt?.let { tx ->
        val member = membersMap[tx.memberId]
        if (member != null && settings != null) {
            ReceiptDialog(
                transaction = tx,
                member = member,
                settings = settings!!,
                arrearsAfterTx = 0.0,
                onDismiss = { selectedTxForReceipt = null }
            )
        }
    }
}
