package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SocietyViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun FirebaseSetupGuideScreen(viewModel: SocietyViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4))
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = EmeraldPrimary)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(GoldSecondary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "ফায়ারবেস ও ক্লাউড ডেটাবেস সেটআপ গাইড",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "ক্লাউড ফায়ারস্টোর স্কিমা, সিকিউরিটি রুলস ও ডেপ্লয়মেন্ট",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "অন-ডিভাইস রিয়েল ডেটাবেস সক্রিয়",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "অ্যাপে স্বয়ংসম্পূর্ণ Room SQLite ডেটাবেস সম্পূর্ণ সক্রিয় রয়েছে। সমস্ত সদস্য, সঞ্চয় জমা এন্ট্রি, স্বয়ংক্রিয় রসিদ, বকেয়া হিসাব, খরচ ও অডিট লগ নিরাপদে সংরক্ষিত হচ্ছে। ক্লাউড ব্যাকআপ ও রিমোট সিঙ্কের জন্য নিচের ফায়ারবেস কনফিগারেশন প্রযোজ্য।",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF424943),
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Collections Architecture
        Text(
            text = "১. ক্লাউড ফায়ারস্টোর কালেকশন কাঠামো",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF181D19)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                SchemaRow("members/{memberId}", "সদস্য প্রোফাইল, সদস্য নং, ফোন, স্থিতি ও লিঙ্কড অ্যাকাউন্ট")
                SchemaRow("savingsTransactions/{txId}", "মাসিক সঞ্চয় জমা, রসিদ নম্বর, জমার মাধ্যম ও স্থিতি")
                SchemaRow("paymentAllocations/{allocId}", "মাসভিত্তিক কিস্তির সুনির্দিষ্ট বণ্টন রেকর্ড")
                SchemaRow("expenses/{expenseId}", "সমিতির অনুমোদিত খরচ ও ভাউচার বিবরণ")
                SchemaRow("bankTransactions/{bankTxId}", "ব্যাংক জমা, উত্তোলন ও নগদ তহবিল সমন্বয়")
                SchemaRow("notices/{noticeId}", "প্রকাশিত সাধারণ ও জরুরি নোটিশ")
                SchemaRow("auditLogs/{logId}", "অপরিবর্তনীয় আর্থিক ও নিরাপত্তা অডিট লগ")
                SchemaRow("appSettings/config", "মাসিক কিস্তির পরিমাণ ও সমিতির সার্বিক নিয়মাবলী")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Security Rules
        Text(
            text = "২. জিরো-ট্রাস্ট সিকিউরিটি রুলস (firestore.rules)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF181D19)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = """rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAdmin() {
      return request.auth != null && 
        request.auth.token.role == 'SUPER_ADMIN';
    }
    function isOwner(memberId) {
      return request.auth != null && 
        request.auth.uid == memberId;
    }

    match /members/{memberId} {
      allow read: if isAdmin() || isOwner(memberId);
      allow write: if isAdmin();
    }

    match /savingsTransactions/{txId} {
      allow read: if isAdmin() || isOwner(resource.data.memberId);
      allow create: if isAdmin();
      allow update, delete: if false; // Immutable!
    }

    match /auditLogs/{logId} {
      allow read: if isAdmin();
      allow create: if request.auth != null;
      allow update, delete: if false; // Append-only!
    }

    match /notices/{noticeId} {
      allow read: if true;
      allow write: if isAdmin();
    }
  }
}""",
                    color = Color(0xFFE2E8F0),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Setup Steps
        Text(
            text = "৩. ডিপ্লয়মেন্ট ও গুগল ক্লাউড সংযোগ নির্দেশনা",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF181D19)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                StepRow(1, "Firebase Console-এ নতুন প্রজেক্ট তৈরি করুন (Asia/Dhaka টাইমজোন)")
                StepRow(2, "Firestore Database ও Authentication চালু করুন (Google Sign-In / Phone)")
                StepRow(3, "প্রজেক্ট সেটিংসে অ্যান্ড্রয়েড অ্যাপ যোগ করে google-services.json ফাইলটি app/ ফোল্ডারে রাখুন")
                StepRow(4, "উপরে বর্ণিত firestore.rules ফাইলটি Firebase CLI দিয়ে ডিপ্লয় করুন:")
                Text(
                    text = "firebase deploy --only firestore:rules",
                    color = EmeraldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(start = 28.dp, top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SchemaRow(collection: String, desc: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = collection,
            fontWeight = FontWeight.Bold,
            color = EmeraldPrimary,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = desc,
            color = Color(0xFF424943),
            fontSize = 11.sp
        )
    }
}

@Composable
private fun StepRow(step: Int, text: String) {
    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(EmeraldPrimary),
            contentAlignment = Alignment.Center
        ) {
            Text(text = step.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, fontSize = 12.sp, color = Color(0xFF181D19))
    }
}
