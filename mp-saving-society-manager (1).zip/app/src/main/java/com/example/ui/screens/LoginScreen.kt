package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MemberEntity
import com.example.ui.SocietyViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(viewModel: SocietyViewModel) {
    val members by viewModel.allMembers.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var adminIdentifier by remember(settings) { mutableStateOf(settings?.masterAdminEmail ?: "raihanulislam296@gmail.com") }
    var adminPin by remember { mutableStateOf("admin123") }
    var selectedMember by remember { mutableStateOf<MemberEntity?>(null) }
    var memberMobileInput by remember { mutableStateOf("") }
    var useDropdownSelection by remember { mutableStateOf(false) }
    var memberPin by remember { mutableStateOf("1234") }
    var isMemberDropdownExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isPinVisible by remember { mutableStateOf(false) }

    if (selectedMember == null && members.isNotEmpty()) {
        selectedMember = members.firstOrNull()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Official Society Logo Emblem
            Surface(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape),
                shape = CircleShape,
                color = Color.White,
                shadowElevation = 6.dp
            ) {
                Image(
                    painter = painterResource(id = R.drawable.society_logo),
                    contentDescription = "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি অফিশিয়াল লোগো",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(4.dp),
                    contentScale = ContentScale.Fit
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = settings?.societyNameBn ?: "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "${settings?.societyNameEn ?: "MP Saving Society"} • ${settings?.location ?: "বাঁশখালী, চট্টগ্রাম"}",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF424943),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Login Box Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "সুরক্ষিত সিস্টেমে প্রবেশ করুন",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                    Text(
                        text = "এডমিন বা সদস্য পোর্টাল নির্বাচন করে প্রবেশ করুন",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    TabRow(
                        selectedTabIndex = selectedTabIndex,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                color = EmeraldPrimary
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTabIndex == 0,
                            onClick = {
                                selectedTabIndex = 0
                                errorMessage = null
                            },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTabIndex == 0) EmeraldPrimary else Color.Gray
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "এডমিন প্যানেল",
                                        fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTabIndex == 0) EmeraldPrimary else Color.Gray
                                    )
                                }
                            }
                        )
                        Tab(
                            selected = selectedTabIndex == 1,
                            onClick = {
                                selectedTabIndex = 1
                                errorMessage = null
                            },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTabIndex == 1) EmeraldPrimary else Color.Gray
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "সদস্য পোর্টাল",
                                        fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTabIndex == 1) EmeraldPrimary else Color.Gray
                                    )
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (selectedTabIndex == 0) {
                        // Super Admin Login
                        Text(
                            text = "এডমিন ইমেইল / জিমেইল *",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = adminIdentifier,
                            onValueChange = { adminIdentifier = it },
                            placeholder = { Text("এডমিন ইমেইল লিখুন") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_identifier_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "এডমিন অ্যাক্সেস পাসওয়ার্ড *",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = adminPin,
                            onValueChange = { adminPin = it },
                            placeholder = { Text("এডমিন পাসওয়ার্ড লিখুন") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = EmeraldPrimary)
                            },
                            trailingIcon = {
                                IconButton(onClick = { isPinVisible = !isPinVisible }) {
                                    Icon(
                                        imageVector = if (isPinVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (isPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_pin_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "🔒 শুধুমাত্র অনুমোদিত এডমিন ও আমন্ত্রিত এডিটরদের প্রবেশাধিকার (ডিফল্ট: admin123)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF6B4A00),
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                if (adminPin.isNotBlank()) {
                                    viewModel.loginAsAdmin(adminIdentifier, adminPin) { success, err ->
                                        if (!success) {
                                            errorMessage = err ?: "ভুল পাসওয়ার্ড! সঠিক তথ্য দিন।"
                                        }
                                    }
                                } else {
                                    errorMessage = "এডমিন পাসওয়ার্ড প্রদান করুন"
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_login_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("এডমিন প্যানেলে প্রবেশ করুন", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Member Login
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFD4EEDF),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "সদস্য রিড-অনলি মোড: সদস্যরা কেবল নিজের হিসাব ও রসিদ দেখতে এবং স্টেটমেন্ট PDF ডাউনলোড করতে পারবেন। কোনো কিছু এডিট করতে পারবেন না।",
                                    fontSize = 11.sp,
                                    color = Color(0xFF042B1A),
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        if (!useDropdownSelection) {
                            // Direct Mobile Number or Member ID Login (Requested by User)
                            Text(
                                text = "মোবাইল নম্বর বা সদস্য আইডি *",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = memberMobileInput,
                                onValueChange = { 
                                    memberMobileInput = it
                                    errorMessage = null
                                },
                                placeholder = { Text("যেমন: 018XXXXXXXX বা MP-0001") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("member_mobile_input")
                            )

                            // Live member preview lookup
                            val trimmedInput = memberMobileInput.trim()
                            val matchedMember = if (trimmedInput.length >= 3) {
                                members.find { m ->
                                    m.mobileNumber.trim() == trimmedInput ||
                                    m.mobileNumber.replace(" ", "").endsWith(trimmedInput.replace(" ", "")) ||
                                    m.memberNumber.equals(trimmedInput, ignoreCase = true) ||
                                    m.memberNumber.replace("MP-", "").trimStart('0') == trimmedInput.trimStart('0')
                                }
                            } else null

                            if (matchedMember != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFD4EEDF),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "স্বাগতম: ${matchedMember.bengaliName} (আইডি: ${matchedMember.memberNumber})",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldPrimary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "সদস্য পিন নম্বর (ডিফল্ট: 1234)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = memberPin,
                                onValueChange = { memberPin = it },
                                placeholder = { Text("পিন নম্বর (ডিফল্ট 1234)") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("member_pin_input"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    val (success, err) = viewModel.loginAsMemberByMobile(memberMobileInput, memberPin)
                                    if (!success) {
                                        errorMessage = err ?: "মোবাইল নম্বর মেলেনি! সঠিক নম্বর প্রদান করুন।"
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("member_login_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("সরাসরি ড্যাশবোর্ডে প্রবেশ করুন", fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.material3.TextButton(
                                onClick = { useDropdownSelection = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("অথবা তালিকা থেকে সদস্য নির্বাচন করুন →", fontSize = 12.sp, color = EmeraldPrimary)
                            }
                        } else {
                            // Dropdown selection fallback
                            Text(
                                text = "সদস্য নির্বাচন করুন *",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            ExposedDropdownMenuBox(
                                expanded = isMemberDropdownExpanded,
                                onExpandedChange = { isMemberDropdownExpanded = !isMemberDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = selectedMember?.let { "${it.bengaliName} (${it.memberNumber})" } ?: "সদস্য নির্বাচন করুন",
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isMemberDropdownExpanded) },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary) },
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                        .testTag("member_select_dropdown")
                                )

                                ExposedDropdownMenu(
                                    expanded = isMemberDropdownExpanded,
                                    onDismissRequest = { isMemberDropdownExpanded = false }
                                ) {
                                    members.forEach { member ->
                                        DropdownMenuItem(
                                            text = {
                                                Column {
                                                    Text(text = member.bengaliName, fontWeight = FontWeight.Bold)
                                                    Text(
                                                        text = "আইডি: ${member.memberNumber} • মোবাইল: ${member.mobileNumber}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = Color.Gray
                                                    )
                                                }
                                            },
                                            onClick = {
                                                selectedMember = member
                                                memberPin = member.linkedPin
                                                isMemberDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "সদস্য গোপন পিন (Default: 1234)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = memberPin,
                                onValueChange = { memberPin = it },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldPrimary) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("member_pin_dropdown_input"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    val member = selectedMember
                                    if (member != null) {
                                        val success = viewModel.loginAsMember(member, memberPin)
                                        if (!success) {
                                            errorMessage = "ভুল পিন কোড! পুনরায় চেষ্টা করুন।"
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("member_login_dropdown_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("সদস্য ড্যাশবোর্ডে প্রবেশ করুন", fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.material3.TextButton(
                                onClick = { useDropdownSelection = false },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("← মোবাইল নম্বর দিয়ে সহজে প্রবেশ করুন", fontSize = 12.sp, color = EmeraldPrimary)
                            }
                        }
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Quick Testing Bar
            Text(
                text = "⚡ তাৎক্ষণিক পরীক্ষামূলক অ্যাক্সেস:",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.loginAsAdmin() },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_admin_login"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldSecondary)
                ) {
                    Text("এডমিন মোড", color = Color(0xFF3E2E00), fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        val firstMember = members.firstOrNull()
                        if (firstMember != null) {
                            viewModel.loginAsMember(firstMember, firstMember.linkedPin)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_member_login"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B8755))
                ) {
                    Text("সদস্য মোড", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
