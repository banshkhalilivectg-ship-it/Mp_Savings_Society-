package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MemberEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.domain.ArrearsCalculator
import com.example.domain.BengaliUtils
import com.example.ui.SocietyViewModel
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.SocietyHeroBanner
import com.example.ui.components.StatementDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun MemberDashboardScreen(
    member: MemberEntity,
    viewModel: SocietyViewModel
) {
    val settings by viewModel.settings.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val allocations by viewModel.allAllocations.collectAsState()
    val notices by viewModel.publishedNotices.collectAsState()

    var showStatementDialog by remember { mutableStateOf(false) }
    var selectedTxForReceipt by remember { mutableStateOf<SavingsTransactionEntity?>(null) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var selectedMonthFilter by remember { mutableStateOf("ALL") } // ALL, PAID, DUE

    val memberSummary = remember(member, settings, allocations, transactions) {
        ArrearsCalculator.calculateForMember(
            member = member,
            settings = settings ?: com.example.data.model.SocietySettingsEntity(),
            allocations = allocations,
            transactions = transactions
        )
    }

    val paidMonths = remember(memberSummary) {
        memberSummary.monthlyItems.filter { it.status == com.example.domain.PaymentStatusType.FULLY_PAID }
    }

    val dueMonths = remember(memberSummary) {
        memberSummary.monthlyItems.filter {
            it.status == com.example.domain.PaymentStatusType.UNPAID ||
            it.status == com.example.domain.PaymentStatusType.PARTIALLY_PAID
        }
    }

    val filteredMonthlyItems = remember(memberSummary, selectedMonthFilter) {
        when (selectedMonthFilter) {
            "PAID" -> paidMonths
            "DUE" -> dueMonths
            else -> memberSummary.monthlyItems
        }
    }

    val memberTransactions = remember(transactions, member) {
        transactions.filter { it.memberId == member.id && !it.isReversed }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4)),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Branding Banner
        item {
            SocietyHeroBanner(
                societyNameBn = settings?.societyNameBn ?: "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
                societyNameEn = settings?.societyNameEn ?: "MP Saving Society",
                location = settings?.location ?: "বাঁশখালী, চট্টগ্রাম, বাংলাদেশ"
            )
        }

        // Member Welcome & Status Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = member.memberNumber.replace("MP-", "#"),
                                    fontWeight = FontWeight.Bold,
                                    color = GoldSecondary,
                                    fontSize = 15.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = member.bengaliName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF181D19)
                                )
                                Text(
                                    text = "সদস্য নং: ${member.memberNumber} • ${member.mobileNumber}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFD4EEDF)
                        ) {
                            Text(
                                text = "সক্রিয় সদস্য",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF042B1A)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Stat metric badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFD4EEDF)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(text = "মোট সঞ্চয়", fontSize = 11.sp, color = Color(0xFF042B1A))
                                Text(
                                    text = BengaliUtils.formatTaka(memberSummary.totalPaid),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF042B1A)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (memberSummary.totalArrears > 0) Color(0xFFFFDAD6) else Color(0xFFE9F1EB)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "বকেয়া",
                                    fontSize = 11.sp,
                                    color = if (memberSummary.totalArrears > 0) Color(0xFFBA1A1A) else Color(0xFF181D19)
                                )
                                Text(
                                    text = BengaliUtils.formatTaka(memberSummary.totalArrears),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (memberSummary.totalArrears > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A)
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFBEBC7)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(text = "বকেয়া মাস", fontSize = 11.sp, color = Color(0xFF6B4A00))
                                Text(
                                    text = "${BengaliUtils.toBengaliDigits(memberSummary.unpaidMonthsCount)} মাস",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF6B4A00)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Buttons: Personal Statement & Change PIN
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showStatementDialog = true },
                            modifier = Modifier
                                .weight(2f)
                                .height(46.dp)
                                .testTag("member_statement_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ব্যক্তিগত বিবরণী PDF", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { showChangePinDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পিন বদল", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Society Notices for Member
        if (notices.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Text(
                        text = "সমিতির সাম্প্রতিক নোটিশ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFBEBC7)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        val notice = notices.first()
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = Color(0xFF92400E))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = notice.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF4A3700))
                                Text(text = notice.content, fontSize = 11.sp, color = Color(0xFF6B4A00))
                            }
                        }
                    }
                }
            }
        }

        // Ultra-clear summary card: Paid vs Due Months at a glance
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFDCE2DC))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "📊 আমার জমার সারসংক্ষেপ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = EmeraldPrimary
                        )
                        Text(
                            text = "মোট সঞ্চয়: ${BengaliUtils.formatTaka(memberSummary.totalPaid)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF042B1A)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Green Paid block
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFD4EEDF),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "পরিশোধিত মাসসমূহ (${BengaliUtils.toBengaliDigits(paidMonths.size)} টি মাস):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF042B1A)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            if (paidMonths.isNotEmpty()) {
                                Text(
                                    text = paidMonths.joinToString(", ") { it.monthNameBn },
                                    fontSize = 11.sp,
                                    color = Color(0xFF0D5C3A),
                                    lineHeight = 16.sp
                                )
                            } else {
                                Text(text = "এখনও কোনো মাস পরিশোধ হয়নি।", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Red Due block
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (dueMonths.isNotEmpty()) Color(0xFFFFDAD6) else Color(0xFFE9F1EB),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (dueMonths.isNotEmpty()) Icons.Default.Warning else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (dueMonths.isNotEmpty()) Color(0xFFBA1A1A) else EmeraldPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (dueMonths.isNotEmpty()) "বকেয়া মাসসমূহ (${BengaliUtils.toBengaliDigits(dueMonths.size)} টি মাস):" else "বকেয়া হিসাব:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (dueMonths.isNotEmpty()) Color(0xFFBA1A1A) else EmeraldPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            if (dueMonths.isNotEmpty()) {
                                Text(
                                    text = "${dueMonths.joinToString(", ") { it.monthNameBn }} (মোট বকেয়া: ${BengaliUtils.formatTaka(memberSummary.totalArrears)})",
                                    fontSize = 11.sp,
                                    color = Color(0xFF93000A),
                                    fontWeight = FontWeight.SemiBold,
                                    lineHeight = 16.sp
                                )
                            } else {
                                Text(
                                    text = "✓ আলহামদুলিল্লাহ! আপনার কোনো বকেয়া পাওনা নেই।",
                                    fontSize = 11.sp,
                                    color = Color(0xFF0D5C3A),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Month-by-Month Status Header & Filter Chips
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text(
                    text = "মাসিক কিস্তির পূর্ণাঙ্গ তালিকা (২০২৬)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF181D19)
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedMonthFilter == "ALL",
                        onClick = { selectedMonthFilter = "ALL" },
                        label = { Text("সব মাস (${memberSummary.monthlyItems.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = selectedMonthFilter == "PAID",
                        onClick = { selectedMonthFilter = "PAID" },
                        label = { Text("পরিশোধিত (${paidMonths.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0D5C3A),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = selectedMonthFilter == "DUE",
                        onClick = { selectedMonthFilter = "DUE" },
                        label = { Text("বকেয়া (${dueMonths.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFBA1A1A),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        items(filteredMonthlyItems, key = { "${it.year}_${it.month}" }) { item ->
            val isPaid = item.status == com.example.domain.PaymentStatusType.FULLY_PAID
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, if (isPaid) Color(0xFFBCE3CB) else Color(0xFFFFDAD6))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${item.monthNameBn} ${BengaliUtils.toBengaliDigits(item.year)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "নির্ধারিত: ${BengaliUtils.formatTaka(item.dueAmount)} • জমা: ${BengaliUtils.formatTaka(item.paidAmount)}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        if (item.paymentDate != null) {
                            Text(
                                text = "পরিশোধের তারিখ: ${BengaliUtils.toBengaliDigits(item.paymentDate)}",
                                fontSize = 10.sp,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    StatusBadge(status = item.status, label = item.statusLabelBn)
                }
            }
        }

        // Recent Receipts
        if (memberTransactions.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(
                        text = "আমার পরিশোধিত রসিদসমূহ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF181D19)
                    )
                }
            }

            items(memberTransactions) { tx ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable { selectedTxForReceipt = tx },
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Receipt, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = tx.receiptNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = "${BengaliUtils.getBengaliMonthName(tx.month)} • ${BengaliUtils.formatBengaliDate(tx.paymentDate)}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = BengaliUtils.formatTaka(tx.amount), fontWeight = FontWeight.Bold, color = EmeraldPrimary, fontSize = 13.sp)
                            Text(text = "রসিদ দেখুন >", fontSize = 10.sp, color = Color(0xFF0284C7), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }

    if (showStatementDialog && settings != null) {
        StatementDialog(
            member = member,
            summary = memberSummary,
            settings = settings!!,
            onDismiss = { showStatementDialog = false }
        )
    }

    selectedTxForReceipt?.let { tx ->
        if (settings != null) {
            ReceiptDialog(
                transaction = tx,
                member = member,
                settings = settings!!,
                arrearsAfterTx = memberSummary.totalArrears,
                onDismiss = { selectedTxForReceipt = null }
            )
        }
    }

    if (showChangePinDialog) {
        ChangePinDialog(
            currentPin = member.linkedPin,
            onDismiss = { showChangePinDialog = false },
            onSave = { newPin ->
                viewModel.saveMember(
                    id = member.id,
                    bengaliName = member.bengaliName,
                    englishName = member.englishName,
                    memberNumber = member.memberNumber,
                    mobileNumber = member.mobileNumber,
                    address = member.address,
                    joinDate = member.joinDate,
                    status = member.status,
                    notes = member.notes,
                    linkedPin = newPin
                )
                showChangePinDialog = false
            }
        )
    }
}

@Composable
private fun ChangePinDialog(
    currentPin: String,
    onDismiss: () -> Unit,
    onSave: (newPin: String) -> Unit
) {
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(20.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "সদস্য গোপন পিন পরিবর্তন",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = newPin,
                    onValueChange = { newPin = it },
                    label = { Text("নতুন ৪-ডিজিট পিন") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { confirmPin = it },
                    label = { Text("নতুন পিন পুনরায় লিখুন") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (error != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = error ?: "", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("বাতিল")
                    }
                    Button(
                        onClick = {
                            if (newPin.length < 4) {
                                error = "পিন অন্তত ৪ অক্ষরের হতে হবে"
                            } else if (newPin != confirmPin) {
                                error = "দুই পিন মেলেনি"
                            } else {
                                onSave(newPin)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("সংরক্ষণ")
                    }
                }
            }
        }
    }
}
