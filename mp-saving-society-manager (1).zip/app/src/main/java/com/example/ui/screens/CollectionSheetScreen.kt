package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MemberEntity
import com.example.data.model.SocietySettingsEntity
import com.example.domain.BengaliUtils
import com.example.domain.PdfReportGenerator
import com.example.ui.ScreenDestination
import com.example.ui.SocietyViewModel
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun CollectionSheetScreen(viewModel: SocietyViewModel) {
    val context = LocalContext.current
    val members by viewModel.allMembers.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val currentSett = settings ?: SocietySettingsEntity()

    var selectedMonth by remember { mutableIntStateOf(10) } // Default October
    var selectedYear by remember { mutableIntStateOf(2026) }
    var filterStatus by remember { mutableStateOf("ALL") } // ALL, PAID, DUE
    var searchQuery by remember { mutableStateOf("") }

    val monthNames = listOf(
        Pair(1, "জানুয়ারি"), Pair(2, "ফেব্রুয়ারি"), Pair(3, "মার্চ"),
        Pair(4, "এপ্রিল"), Pair(5, "মে"), Pair(6, "জুন"),
        Pair(7, "জুলাই"), Pair(8, "আগস্ট"), Pair(9, "সেপ্টেম্বর"),
        Pair(10, "অক্টোবর"), Pair(11, "নভেম্বর"), Pair(12, "ডিসেম্বর")
    )

    // Calculate month deposits map
    val monthPaidMap = remember(transactions, selectedMonth, selectedYear) {
        val validTxs = transactions.filter { !it.isReversed && it.month == selectedMonth && it.year == selectedYear }
        val map = mutableMapOf<Long, Double>()
        for (tx in validTxs) {
            map[tx.memberId] = (map[tx.memberId] ?: 0.0) + tx.amount
        }
        map
    }

    val totalSavingsMap = remember(transactions) {
        val validTxs = transactions.filter { !it.isReversed }
        val map = mutableMapOf<Long, Double>()
        for (tx in validTxs) {
            map[tx.memberId] = (map[tx.memberId] ?: 0.0) + tx.amount
        }
        map
    }

    val activeMembers = remember(members) {
        members.filter { it.status == "ACTIVE" }
    }

    val paidMembersCount = remember(activeMembers, monthPaidMap, currentSett) {
        activeMembers.count { (monthPaidMap[it.id] ?: 0.0) >= currentSett.monthlySavingsAmount }
    }

    val totalCollectedThisMonth = remember(transactions, selectedMonth, selectedYear) {
        transactions.filter { !it.isReversed && it.month == selectedMonth && it.year == selectedYear }.sumOf { it.amount }
    }

    val dueMembersCount = remember(activeMembers, paidMembersCount) {
        (activeMembers.size - paidMembersCount).coerceAtLeast(0)
    }

    val totalDueThisMonth = remember(dueMembersCount, currentSett) {
        dueMembersCount * currentSett.monthlySavingsAmount
    }

    val filteredList = remember(activeMembers, monthPaidMap, filterStatus, searchQuery, currentSett) {
        activeMembers.filter { member ->
            val paid = monthPaidMap[member.id] ?: 0.0
            val isPaid = paid >= currentSett.monthlySavingsAmount
            val matchesFilter = when (filterStatus) {
                "PAID" -> isPaid
                "DUE" -> !isPaid
                else -> true
            }
            val matchesSearch = searchQuery.isBlank() ||
                    member.bengaliName.contains(searchQuery, ignoreCase = true) ||
                    member.memberNumber.contains(searchQuery, ignoreCase = true) ||
                    member.mobileNumber.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    fun shareToWhatsApp() {
        val monthNameBn = BengaliUtils.getBengaliMonthName(selectedMonth)
        val sb = StringBuilder()
        sb.append("════════════════════════\n")
        sb.append("🏦 ${currentSett.societyNameBn}\n")
        sb.append("📍 ${currentSett.location}\n")
        sb.append("📋 মাসিক সঞ্চয় আদায় ও সদস্য তালিকা\n")
        sb.append("📅 মাস: $monthNameBn ${BengaliUtils.toBengaliDigits(selectedYear)}\n")
        sb.append("════════════════════════\n")
        sb.append("📊 সারসংক্ষেপ রিপোর্ট:\n")
        sb.append("• মোট সক্রিয় সদস্য: ${BengaliUtils.toBengaliDigits(activeMembers.size)} জন\n")
        sb.append("• জমা দিয়েছেন: ${BengaliUtils.toBengaliDigits(paidMembersCount)} জন (মোট ${BengaliUtils.formatTaka(totalCollectedThisMonth)})\n")
        sb.append("• বকেয়া রয়েছে: ${BengaliUtils.toBengaliDigits(dueMembersCount)} জন (মোট ${BengaliUtils.formatTaka(totalDueThisMonth)})\n")
        sb.append("════════════════════════\n")
        sb.append("✅ সদস্যভিত্তিক জমার বিবরণী:\n\n")

        activeMembers.forEachIndexed { idx, m ->
            val paid = monthPaidMap[m.id] ?: 0.0
            val isPaid = paid >= currentSett.monthlySavingsAmount
            val serial = BengaliUtils.toBengaliDigits(idx + 1)
            if (isPaid) {
                sb.append("$serial. ${m.bengaliName} (${m.memberNumber})\n   ↳ জমা: ${BengaliUtils.formatTaka(paid)} [পরিশোধিত ✓]\n")
            } else {
                sb.append("$serial. ${m.bengaliName} (${m.memberNumber})\n   ↳ জমা: ৳ ০ [বকেয়া: ${BengaliUtils.formatTaka(currentSett.monthlySavingsAmount)} ✕]\n")
            }
        }

        sb.append("\n════════════════════════\n")
        sb.append("সঞ্চয়ে সমৃদ্ধি, ঐক্যে উন্নয়ন।\n")
        sb.append("তারিখ: ${BengaliUtils.getCurrentTimestampFormatted()}")

        val reportText = sb.toString()

        // Copy to clipboard
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Society Collection Report", reportText)
        clipboard.setPrimaryClip(clip)

        // Share via Intent
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, reportText)
        }
        context.startActivity(Intent.createChooser(sendIntent, "হোয়াটসঅ্যাপে তালিকা শেয়ার করুন"))
        Toast.makeText(context, "রিপোর্ট কপি হয়েছে এবং শেয়ার অপশন খোলা হচ্ছে...", Toast.LENGTH_SHORT).show()
    }

    fun downloadPdf() {
        val pdfFile = PdfReportGenerator.generateMonthlyCollectionSheetPdf(
            context = context,
            month = selectedMonth,
            year = selectedYear,
            members = members,
            transactions = transactions,
            settings = currentSett
        )
        if (pdfFile != null) {
            PdfReportGenerator.sharePdfFile(context, pdfFile, "মাসিক কালেকশন শিট PDF")
        } else {
            Toast.makeText(context, "PDF তৈরিতে সমস্যা হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4)),
        contentPadding = PaddingValues(bottom = 40.dp)
    ) {
        // Top Header Banner with Logo
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.society_logo),
                            contentDescription = "সমিতির লগো",
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentSett.societyNameBn,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "${currentSett.location} • স্থাপিত: ২০২৬",
                                style = MaterialTheme.typography.bodySmall,
                                color = GoldSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "মাসিক সঞ্চয় আদায় তালিকা (গ্রুপ নোটিশ)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Month Selector Chips
                    Text(
                        text = "মাস নির্বাচন করুন:",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(monthNames, key = { it.first }) { (moNum, moName) ->
                            val isSelected = selectedMonth == moNum
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) GoldSecondary else Color(0xFF14734B),
                                modifier = Modifier
                                    .padding(vertical = 2.dp),
                                onClick = { selectedMonth = moNum }
                            ) {
                                Text(
                                    text = moName,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color(0xFF281C00) else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // Summary Metric Tiles
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD4EEDF)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পরিশোধ করেছেন", fontSize = 10.sp, color = Color(0xFF042B1A))
                        }
                        Text(
                            text = "${BengaliUtils.toBengaliDigits(paidMembersCount)} জন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF042B1A)
                        )
                        Text(
                            text = BengaliUtils.formatTaka(totalCollectedThisMonth),
                            fontSize = 11.sp,
                            color = Color(0xFF042B1A),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = if (dueMembersCount > 0) Color(0xFFFFDAD6) else Color(0xFFE9F1EB)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = if (dueMembersCount > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("বকেয়া রয়েছে", fontSize = 10.sp, color = if (dueMembersCount > 0) Color(0xFFBA1A1A) else Color(0xFF181D19))
                        }
                        Text(
                            text = "${BengaliUtils.toBengaliDigits(dueMembersCount)} জন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (dueMembersCount > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A)
                        )
                        Text(
                            text = BengaliUtils.formatTaka(totalDueThisMonth),
                            fontSize = 11.sp,
                            color = if (dueMembersCount > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // WhatsApp Share & PDF Download Primary Buttons
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { shareToWhatsApp() },
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp)
                        .testTag("whatsapp_share_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("হোয়াটসঅ্যাপে শেয়ার", fontWeight = FontWeight.Bold, color = Color.White)
                }

                Button(
                    onClick = { downloadPdf() },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("download_collection_pdf_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PDF ডাউনলোড", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Search and Filter Bar
        item {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("সদস্য নাম, মোবাইল বা আইডি খুঁজুন...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("collection_search_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = filterStatus == "ALL",
                        onClick = { filterStatus = "ALL" },
                        label = { Text("সবাই (${activeMembers.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = filterStatus == "PAID",
                        onClick = { filterStatus = "PAID" },
                        label = { Text("পরিশোধিত ($paidMembersCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0D5C3A),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = filterStatus == "DUE",
                        onClick = { filterStatus = "DUE" },
                        label = { Text("বকেয়া ($dueMembersCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFBA1A1A),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // List Header Count
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${BengaliUtils.getBengaliMonthName(selectedMonth)} ২০২৬ জমার খতিয়ান",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF181D19)
                )
                Text(
                    text = "মোট: ${BengaliUtils.toBengaliDigits(filteredList.size)} জন",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        // Members Collection List Items
        itemsIndexed(filteredList, key = { _, member -> member.id }) { index, member ->
            val paid = monthPaidMap[member.id] ?: 0.0
            val totalSaved = totalSavingsMap[member.id] ?: 0.0
            val isPaid = paid >= currentSett.monthlySavingsAmount

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, if (isPaid) Color(0xFFBCE3CB) else Color(0xFFFFDAD6)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Serial & Member Badge
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (isPaid) Color(0xFFD4EEDF) else Color(0xFFFFDAD6)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = BengaliUtils.toBengaliDigits(index + 1),
                            fontWeight = FontWeight.Bold,
                            color = if (isPaid) Color(0xFF042B1A) else Color(0xFFBA1A1A),
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Member Details
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = member.bengaliName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF181D19)
                        )
                        Text(
                            text = "আইডি: ${member.memberNumber} • 📱 ${member.mobileNumber}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "মোট সঞ্চয়: ${BengaliUtils.formatTaka(totalSaved)}",
                            fontSize = 11.sp,
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Status and Amount Badge
                    Column(horizontalAlignment = Alignment.End) {
                        if (isPaid) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFD4EEDF)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = BengaliUtils.formatTaka(paid),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF042B1A)
                                    )
                                }
                            }
                            Text(
                                text = "পরিশোধিত ✓",
                                fontSize = 10.sp,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        } else {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFFFDAD6)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFBA1A1A), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "বকেয়া",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFFBA1A1A)
                                    )
                                }
                            }
                            Text(
                                text = "পাওনা: ${BengaliUtils.formatTaka(currentSett.monthlySavingsAmount)}",
                                fontSize = 10.sp,
                                color = Color(0xFFBA1A1A),
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
