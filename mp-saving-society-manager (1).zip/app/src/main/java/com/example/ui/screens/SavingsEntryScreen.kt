package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.domain.BengaliUtils
import com.example.ui.SocietyViewModel
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavingsEntryScreen(viewModel: SocietyViewModel) {
    val members by viewModel.allMembers.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val defaultAmount = settings?.monthlySavingsAmount ?: 500.0

    var selectedMember by remember { mutableStateOf<MemberEntity?>(null) }
    var isMemberExpanded by remember { mutableStateOf(false) }

    var selectedMonth by remember { mutableIntStateOf(10) } // 10 = October
    var isMonthExpanded by remember { mutableStateOf(false) }

    var selectedYear by remember { mutableIntStateOf(2026) }

    var amountText by remember { mutableStateOf(defaultAmount.toInt().toString()) }
    var paymentMethod by remember { mutableStateOf("CASH") }
    var collectorName by remember { mutableStateOf("সুপার এডমিন (রফিকুল ইসলাম)") }
    var paymentDate by remember { mutableStateOf(BengaliUtils.getCurrentDateIso()) }
    var note by remember { mutableStateOf("") }

    var generatedReceiptTx by remember { mutableStateOf<SavingsTransactionEntity?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    if (selectedMember == null && members.isNotEmpty()) {
        selectedMember = members.firstOrNull()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4))
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(EmeraldPrimary.copy(alpha = 0.12f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AddCard, contentDescription = null, tint = EmeraldPrimary)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "মাসিক সঞ্চয় জমা এন্ট্রি",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF181D19)
                        )
                        Text(
                            text = "লেজার আপডেট এবং স্বয়ংক্রিয় রসিদ তৈরি",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Member Dropdown
                Text(text = "সদস্য নির্বাচন করুন *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                ExposedDropdownMenuBox(
                    expanded = isMemberExpanded,
                    onExpandedChange = { isMemberExpanded = !isMemberExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedMember?.let { "${it.bengaliName} (${it.memberNumber}) - ${it.mobileNumber}" } ?: "সদস্য নির্বাচন করুন",
                        onValueChange = {},
                        readOnly = true,
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isMemberExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("savings_member_dropdown")
                    )

                    ExposedDropdownMenu(
                        expanded = isMemberExpanded,
                        onDismissRequest = { isMemberExpanded = false }
                    ) {
                        members.forEach { m ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(text = "${m.bengaliName} (${m.memberNumber})", fontWeight = FontWeight.Bold)
                                        Text(text = "মোবাইল: ${m.mobileNumber}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                },
                                onClick = {
                                    selectedMember = m
                                    isMemberExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Month & Year Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Text(text = "সঞ্চয় মাস *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))

                        ExposedDropdownMenuBox(
                            expanded = isMonthExpanded,
                            onExpandedChange = { isMonthExpanded = !isMonthExpanded }
                        ) {
                            OutlinedTextField(
                                value = BengaliUtils.getBengaliMonthName(selectedMonth),
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isMonthExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                                    .testTag("savings_month_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = isMonthExpanded,
                                onDismissRequest = { isMonthExpanded = false }
                            ) {
                                for (m in 1..12) {
                                    DropdownMenuItem(
                                        text = { Text(BengaliUtils.getBengaliMonthName(m)) },
                                        onClick = {
                                            selectedMonth = m
                                            isMonthExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "বছর", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = selectedYear.toString(),
                            onValueChange = { selectedYear = it.toIntOrNull() ?: 2026 },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Amount
                Text(text = "জমার পরিমাণ (টাকা) *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("savings_amount_input"),
                    singleLine = true,
                    leadingIcon = {
                        Text(
                            text = "৳",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Fast Amount Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(500, 1000, 1500, 2000).forEach { amt ->
                        FilterChip(
                            selected = amountText == amt.toString(),
                            onClick = { amountText = amt.toString() },
                            label = { Text("৳ $amt", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Payment Method
                Text(text = "পরিশোধ পদ্ধতি *", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val methods = listOf(
                        "CASH" to "নগদ (ক্যাশ)",
                        "BANK" to "ব্যাংক",
                        "BKASH" to "বিকাশ",
                        "NAGAD" to "নগদ মোবাইল"
                    )

                    methods.forEach { (key, label) ->
                        FilterChip(
                            selected = paymentMethod == key,
                            onClick = { paymentMethod = key },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldSecondary,
                                selectedLabelColor = Color(0xFF3E2E00)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Date & Collector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = paymentDate,
                        onValueChange = { paymentDate = it },
                        label = { Text("পরিশোধ তারিখ") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = collectorName,
                        onValueChange = { collectorName = it },
                        label = { Text("আদায়কারী") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("মন্তব্য / নোট (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val member = selectedMember
                        val amount = amountText.toDoubleOrNull()
                        if (member == null) {
                            errorMessage = "সদস্য নির্বাচন করুন"
                        } else if (amount == null || amount <= 0.0) {
                            errorMessage = "সঠিক টাকার পরিমাণ লিখুন"
                        } else {
                            errorMessage = null
                            viewModel.recordSavingsDeposit(
                                memberId = member.id,
                                month = selectedMonth,
                                year = selectedYear,
                                amount = amount,
                                paymentDate = paymentDate,
                                paymentMethod = paymentMethod,
                                recordedBy = collectorName,
                                note = note.ifBlank { null }
                            ) { createdTx ->
                                generatedReceiptTx = createdTx
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_savings_deposit_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Receipt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("সঞ্চয় জমা নিশ্চিত করুন ও রসিদ তৈরি করুন", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    generatedReceiptTx?.let { tx ->
        val member = selectedMember
        if (member != null && settings != null) {
            ReceiptDialog(
                transaction = tx,
                member = member,
                settings = settings!!,
                arrearsAfterTx = 0.0,
                onDismiss = {
                    generatedReceiptTx = null
                    viewModel.clearRecentReceipt()
                }
            )
        }
    }
}
