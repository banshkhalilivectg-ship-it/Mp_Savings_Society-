package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.domain.ArrearsCalculator
import com.example.domain.BengaliUtils
import com.example.domain.MemberArrearsSummary
import com.example.ui.SocietyViewModel
import com.example.ui.components.StatementDialog
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun ArrearsReportScreen(viewModel: SocietyViewModel) {
    val members by viewModel.allMembers.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val allocations by viewModel.allAllocations.collectAsState()

    var sortBy by remember { mutableStateOf("AMOUNT") } // AMOUNT, MONTHS, NUMBER
    var selectedSummaryForStatement by remember { mutableStateOf<Pair<MemberEntity, MemberArrearsSummary>?>(null) }

    val membersMap = remember(members) { members.associateBy { it.id } }

    val allSummaries = remember(members, settings, allocations, transactions) {
        val sett = settings ?: com.example.data.model.SocietySettingsEntity()
        members.filter { it.status == "ACTIVE" }.map { m ->
            val summary = ArrearsCalculator.calculateForMember(
                member = m,
                settings = sett,
                allocations = allocations,
                transactions = transactions
            )
            Pair(m, summary)
        }
    }

    val sortedList = remember(allSummaries, sortBy) {
        when (sortBy) {
            "AMOUNT" -> allSummaries.sortedByDescending { it.second.totalArrears }
            "MONTHS" -> allSummaries.sortedByDescending { it.second.unpaidMonthsCount }
            else -> allSummaries.sortedBy { it.first.memberNumber }
        }
    }

    val totalSocietyArrears = remember(allSummaries) {
        allSummaries.sumOf { it.second.totalArrears }
    }

    val overdueMembersCount = remember(allSummaries) {
        allSummaries.count { it.second.totalArrears > 0 }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7F4))
            .padding(16.dp)
    ) {
        // Summary Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = if (totalSocietyArrears > 0) Color(0xFFFFDAD6) else Color(0xFFD4EEDF))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "সমিতির মোট বকেয়া পাওনা",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (totalSocietyArrears > 0) Color(0xFFBA1A1A) else Color(0xFF042B1A)
                    )
                    Text(
                        text = BengaliUtils.formatTaka(totalSocietyArrears),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (totalSocietyArrears > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A)
                    )
                    Text(
                        text = "মোট বকেয়াগ্রস্ত সদস্য: ${BengaliUtils.toBengaliDigits(overdueMembersCount)} জন",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (totalSocietyArrears > 0) Color(0xFF410002) else Color(0xFF042B1A),
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (totalSocietyArrears > 0) Color(0xFFBA1A1A).copy(alpha = 0.2f) else EmeraldPrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (totalSocietyArrears > 0) Color(0xFFBA1A1A) else EmeraldPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Sorting Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "সর্ট করুন:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)

            FilterChip(
                selected = sortBy == "AMOUNT",
                onClick = { sortBy = "AMOUNT" },
                label = { Text("বকেয়ার পরিমাণ", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White
                )
            )

            FilterChip(
                selected = sortBy == "MONTHS",
                onClick = { sortBy = "MONTHS" },
                label = { Text("বকেয়া মাস", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White
                )
            )

            FilterChip(
                selected = sortBy == "NUMBER",
                onClick = { sortBy = "NUMBER" },
                label = { Text("সদস্য নং", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = Color.White
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Arrears Member List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(sortedList) { (member, summary) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedSummaryForStatement = Pair(member, summary) }
                        .testTag("arrears_item_${member.memberNumber}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(if (summary.totalArrears > 0) Color(0xFFFFDAD6) else Color(0xFFD4EEDF)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = member.memberNumber.replace("MP-", "#"),
                                        fontWeight = FontWeight.Bold,
                                        color = if (summary.totalArrears > 0) Color(0xFFBA1A1A) else EmeraldPrimary,
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = member.bengaliName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF181D19)
                                    )
                                    Text(
                                        text = "${member.memberNumber} • মোবাইল: ${member.mobileNumber}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = BengaliUtils.formatTaka(summary.totalArrears),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (summary.totalArrears > 0) Color(0xFFBA1A1A) else Color(0xFF198754)
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (summary.totalArrears > 0) Color(0xFFFEF3C7) else Color(0xFFD4EEDF)
                                ) {
                                    Text(
                                        text = if (summary.totalArrears > 0) "${BengaliUtils.toBengaliDigits(summary.unpaidMonthsCount)} মাস বকেয়া" else "পরিশোধিত",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (summary.totalArrears > 0) Color(0xFF92400E) else Color(0xFF042B1A)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "নির্ধারিত প্রাপ্য: ${BengaliUtils.formatTaka(summary.totalDue)} • আদায়: ${BengaliUtils.formatTaka(summary.totalPaid)}",
                                fontSize = 11.sp,
                                color = Color(0xFF424943)
                            )

                            Button(
                                onClick = { selectedSummaryForStatement = Pair(member, summary) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("বিবরণী PDF", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    selectedSummaryForStatement?.let { (member, summary) ->
        if (settings != null) {
            StatementDialog(
                member = member,
                summary = summary,
                settings = settings!!,
                onDismiss = { selectedSummaryForStatement = null }
            )
        }
    }
}
