package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MemberEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity
import com.example.domain.BengaliUtils
import com.example.domain.PdfReportGenerator
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary

@Composable
fun ReceiptDialog(
    transaction: SavingsTransactionEntity,
    member: MemberEntity,
    settings: SocietySettingsEntity,
    arrearsAfterTx: Double,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "জমা রসিদ প্রিভিউ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_receipt_dialog")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "বন্ধ করুন")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Printable Receipt Slip Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFC)),
                    border = BorderStroke(1.5.dp, EmeraldPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp)
                    ) {
                        // Header
                        Text(
                            text = settings.societyNameBn,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = settings.location,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .background(GoldSecondary.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "মাসিক সঞ্চয় জমা রসিদ",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF6B4A00)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color(0xFFE0E5E0))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Details
                        ReceiptRow("রসিদ নং:", transaction.receiptNumber, isBold = true)
                        ReceiptRow("তারিখ:", BengaliUtils.formatBengaliDate(transaction.paymentDate))
                        ReceiptRow("সদস্য নাম:", "${member.bengaliName} (${member.englishName})")
                        ReceiptRow("সদস্য নম্বর:", member.memberNumber, isBold = true)
                        ReceiptRow("মোবাইল:", member.mobileNumber)
                        ReceiptRow(
                            "সঞ্চয় মাস:",
                            "${BengaliUtils.getBengaliMonthName(transaction.month)}, ${BengaliUtils.toBengaliDigits(transaction.year)}"
                        )
                        ReceiptRow("পরিশোধ মাধ্যম:", BengaliUtils.getPaymentMethodBn(transaction.paymentMethod))
                        ReceiptRow("আদায়কারী:", transaction.recordedBy)

                        Spacer(modifier = Modifier.height(10.dp))

                        // Amount Highlight Box
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFD4EEDF),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "আদায়কৃত জমার পরিমাণ:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF042B1A)
                                    )
                                    Text(
                                        text = BengaliUtils.formatTaka(transaction.amount),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF042B1A)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "কথায়: ${BengaliUtils.amountInBengaliWords(transaction.amount)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF042B1A),
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "জমা পরবর্তী অবশিষ্ট বকেয়া: ${BengaliUtils.formatTaka(arrearsAfterTx)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (arrearsAfterTx > 0) Color(0xFFBA1A1A) else Color(0xFF0D5C3A),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Signatures
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "---------------------", color = Color.Gray, fontSize = 10.sp)
                                Text(text = "আদায়কারীর স্বাক্ষর", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "---------------------", color = Color.Gray, fontSize = 10.sp)
                                Text(text = "সদস্যের স্বাক্ষর", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons: Share & Print PDF
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray)
                    ) {
                        Text("বন্ধ করুন")
                    }

                    Button(
                        onClick = {
                            val pdfFile = PdfReportGenerator.generateReceiptPdf(
                                context = context,
                                transaction = transaction,
                                member = member,
                                settings = settings,
                                arrearsAfterTx = arrearsAfterTx
                            )
                            if (pdfFile != null) {
                                PdfReportGenerator.sharePdfFile(
                                    context = context,
                                    file = pdfFile,
                                    title = "সঞ্চয় জমা রসিদ PDF"
                                )
                            }
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("share_receipt_pdf_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("রসিদ PDF শেয়ার / প্রিন্ট")
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String, isBold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF4A554D),
            fontSize = 12.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = Color(0xFF181D19),
            fontSize = 12.sp
        )
    }
}
