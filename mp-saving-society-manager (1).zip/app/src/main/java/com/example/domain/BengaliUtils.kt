package com.example.domain

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BengaliUtils {

    private val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    private val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun toBengaliDigits(input: Any?): String {
        if (input == null) return "০"
        val str = input.toString()
        val sb = StringBuilder()
        for (ch in str) {
            val idx = englishDigits.indexOf(ch)
            if (idx != -1) {
                sb.append(bengaliDigits[idx])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatTaka(amount: Double): String {
        val rounded = if (amount % 1.0 == 0.0) amount.toLong().toString() else String.format(Locale.US, "%.2f", amount)
        return "৳ " + toBengaliDigits(rounded)
    }

    fun getBengaliMonthName(month: Int): String {
        return when (month) {
            1 -> "জানুয়ারি"
            2 -> "ফেব্রুয়ারি"
            3 -> "মার্চ"
            4 -> "এপ্রিল"
            5 -> "মে"
            6 -> "জুন"
            7 -> "জুলাই"
            8 -> "আগস্ট"
            9 -> "সেপ্টেম্বর"
            10 -> "অক্টোবর"
            11 -> "নভেম্বর"
            12 -> "ডিসেম্বর"
            else -> "অজানা মাস"
        }
    }

    fun formatBengaliDate(dateStr: String): String {
        // Expected YYYY-MM-DD
        return try {
            val parts = dateStr.split("-")
            if (parts.size == 3) {
                val year = parts[0]
                val month = parts[1].toInt()
                val day = parts[2].toInt()
                "${toBengaliDigits(day)} ${getBengaliMonthName(month)}, ${toBengaliDigits(year)}"
            } else {
                toBengaliDigits(dateStr)
            }
        } catch (e: Exception) {
            toBengaliDigits(dateStr)
        }
    }

    fun getCurrentDateIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun getCurrentTimestampFormatted(): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US)
        return toBengaliDigits(sdf.format(Date()))
    }

    // Convert amount in Taka to words in Bengali
    fun amountInBengaliWords(amount: Double): String {
        val num = amount.toLong()
        if (num <= 0) return "শূন্য টাকা মাত্র"

        val units = arrayOf(
            "", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়",
            "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "উনিশ",
            "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ",
            "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁয়ত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ",
            "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁয়তাল্লিশ", "ছেচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ",
            "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট",
            "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁয়ষট্টি", "ছেষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর",
            "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি",
            "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই",
            "নব্বই", "একানব্বই", "বানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"
        )

        fun convertLessThanThousand(n: Long): String {
            var res = ""
            val hundreds = n / 100
            val remainder = n % 100

            if (hundreds > 0) {
                res += when (hundreds) {
                    1L -> "এক শত "
                    2L -> "দুই শত "
                    3L -> "তিন শত "
                    4L -> "চার শত "
                    5L -> "পাঁচ শত "
                    6L -> "ছয় শত "
                    7L -> "সাত শত "
                    8L -> "আট শত "
                    9L -> "নয় শত "
                    else -> "${toBengaliDigits(hundreds)} শত "
                }
            }
            if (remainder > 0) {
                res += units[remainder.toInt()] + " "
            }
            return res.trim()
        }

        var temp = num
        var words = ""

        val crore = temp / 10000000
        temp %= 10000000

        val lakh = temp / 100000
        temp %= 100000

        val thousand = temp / 1000
        temp %= 1000

        if (crore > 0) {
            words += "${convertLessThanThousand(crore)} কোটি "
        }
        if (lakh > 0) {
            words += "${convertLessThanThousand(lakh)} লক্ষ "
        }
        if (thousand > 0) {
            words += "${convertLessThanThousand(thousand)} হাজার "
        }
        if (temp > 0) {
            words += "${convertLessThanThousand(temp)} "
        }

        return words.trim() + " টাকা মাত্র"
    }

    fun getPaymentMethodBn(method: String): String {
        return when (method.uppercase()) {
            "CASH" -> "নগদ (ক্যাশ)"
            "BANK" -> "ব্যাংক ডিপোজিট"
            "BKASH" -> "বিকাশ"
            "NAGAD" -> "নগদ (মোবাইল ব্যাংকিং)"
            "ROCKET" -> "রকেট"
            else -> method
        }
    }

    fun getExpenseCategoryBn(category: String): String {
        return when (category.uppercase()) {
            "OFFICE" -> "অফিস ও স্টেশনারি খরচ"
            "MEETING" -> "সাধারণ সভা ও আপ্যায়ন"
            "WELFARE" -> "সদস্য কল্যাণ ও অনুদান"
            "PRINTING" -> "রসিদ ও খাতা মুদ্রণ"
            "AUDIT" -> "নিরীক্ষা ও হিসাব পরিচালনা"
            "MISC" -> "বিবিধ খরচ"
            else -> category
        }
    }

    fun getStatusLabelBn(status: String): String {
        return when (status.uppercase()) {
            "ACTIVE" -> "সক্রিয়"
            "SUSPENDED" -> "সাময়িক স্থগিত"
            "ARCHIVED" -> "আর্কাইভ"
            else -> status
        }
    }
}
