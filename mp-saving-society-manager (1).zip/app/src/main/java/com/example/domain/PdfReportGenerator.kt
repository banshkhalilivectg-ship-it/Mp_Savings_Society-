package com.example.domain

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.MemberEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity
import java.io.File
import java.io.FileOutputStream

object PdfReportGenerator {

    fun generateMemberStatementPdf(
        context: Context,
        member: MemberEntity,
        summary: MemberArrearsSummary,
        settings: SocietySettingsEntity
    ): File? {
        val document = PdfDocument()
        val pageWidth = 595 // Standard A4 points at 72 DPI
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Background
        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        textPaint.color = Color.parseColor("#181D19")

        // Top Header Banner (Emerald)
        paint.color = Color.parseColor("#0D5C3A")
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 95f, paint)

        // Gold decorative accent line
        paint.color = Color.parseColor("#C59B27")
        paint.strokeWidth = 4f
        canvas.drawLine(0f, 95f, pageWidth.toFloat(), 95f, paint)

        // Draw Official Society Logo
        val logoBitmap = try {
            BitmapFactory.decodeResource(context.resources, R.drawable.society_logo)
        } catch (_: Exception) { null }

        if (logoBitmap != null) {
            canvas.drawBitmap(logoBitmap, null, RectF(20f, 15f, 85f, 80f), paint)
        }

        // Header Text
        textPaint.color = Color.WHITE
        textPaint.textSize = 16f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(settings.societyNameBn, pageWidth / 2f + 25f, 38f, textPaint)

        textPaint.textSize = 10f
        textPaint.typeface = Typeface.DEFAULT
        canvas.drawText("${settings.societyNameEn} • ${settings.location}", pageWidth / 2f + 25f, 56f, textPaint)

        textPaint.textSize = 12f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.color = Color.parseColor("#FFD97D")
        canvas.drawText("সদস্য ব্যক্তিগত সঞ্চয় বিবরণী (MEMBER STATEMENT)", pageWidth / 2f + 25f, 78f, textPaint)

        // Reset Text Alignment
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.parseColor("#181D19")

        // Member Info Box
        val boxTop = 110f
        val boxHeight = 70f
        paint.color = Color.parseColor("#F4F7F4")
        paint.style = Paint.Style.FILL
        val cardRect = RectF(25f, boxTop, pageWidth - 25f, boxTop + boxHeight)
        canvas.drawRoundRect(cardRect, 8f, 8f, paint)

        paint.color = Color.parseColor("#C2C9C1")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(cardRect, 8f, 8f, paint)

        // Member Details
        textPaint.textSize = 11f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("সদস্য নাম: ${member.bengaliName} (${member.englishName})", 40f, boxTop + 24f, textPaint)
        textPaint.typeface = Typeface.DEFAULT
        canvas.drawText("সদস্য নং: ${member.memberNumber}", 40f, boxTop + 42f, textPaint)
        canvas.drawText("মোবাইল: ${member.mobileNumber}", 40f, boxTop + 58f, textPaint)

        canvas.drawText("যোগদানের তারিখ: ${BengaliUtils.formatBengaliDate(member.joinDate)}", 320f, boxTop + 24f, textPaint)
        canvas.drawText("স্থিতি: ${BengaliUtils.getStatusLabelBn(member.status)}", 320f, boxTop + 42f, textPaint)
        canvas.drawText("বিবরণী প্রদানের তারিখ: ${BengaliUtils.getCurrentTimestampFormatted()}", 320f, boxTop + 58f, textPaint)

        // Table Header
        val tableTop = 195f
        paint.color = Color.parseColor("#0D5C3A")
        paint.style = Paint.Style.FILL
        canvas.drawRect(25f, tableTop, pageWidth - 25f, tableTop + 25f, paint)

        textPaint.color = Color.WHITE
        textPaint.textSize = 10f
        textPaint.typeface = Typeface.DEFAULT_BOLD

        val col1 = 35f  // মাস
        val col2 = 130f // নির্ধারিত জমা
        val col3 = 220f // আদায়কৃত জমা
        val col4 = 310f // পরিশোধ তারিখ
        val col5 = 405f // রসিদ নং
        val col6 = 490f // স্থিতি

        canvas.drawText("মাস ও বছর", col1, tableTop + 17f, textPaint)
        canvas.drawText("নির্ধারিত", col2, tableTop + 17f, textPaint)
        canvas.drawText("আদায়", col3, tableTop + 17f, textPaint)
        canvas.drawText("পরিশোধ তারিখ", col4, tableTop + 17f, textPaint)
        canvas.drawText("রসিদ নং", col5, tableTop + 17f, textPaint)
        canvas.drawText("স্থিতি", col6, tableTop + 17f, textPaint)

        // Table Rows
        var currentY = tableTop + 25f
        textPaint.color = Color.parseColor("#181D19")
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 9.5f

        for ((index, item) in summary.monthlyItems.withIndex()) {
            if (index % 2 == 1) {
                paint.color = Color.parseColor("#F9FAF9")
                paint.style = Paint.Style.FILL
                canvas.drawRect(25f, currentY, pageWidth - 25f, currentY + 22f, paint)
            }

            paint.color = Color.parseColor("#E5E9E5")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 0.5f
            canvas.drawLine(25f, currentY + 22f, pageWidth - 25f, currentY + 22f, paint)

            canvas.drawText("${item.monthNameBn} ${BengaliUtils.toBengaliDigits(item.year)}", col1, currentY + 15f, textPaint)
            canvas.drawText(BengaliUtils.formatTaka(item.dueAmount), col2, currentY + 15f, textPaint)
            canvas.drawText(BengaliUtils.formatTaka(item.paidAmount), col3, currentY + 15f, textPaint)
            canvas.drawText(item.paymentDate?.let { BengaliUtils.toBengaliDigits(it) } ?: "-", col4, currentY + 15f, textPaint)
            canvas.drawText(item.receiptNumber ?: "-", col5, currentY + 15f, textPaint)

            // Status Badge text
            val oldColor = textPaint.color
            if (item.status == PaymentStatusType.FULLY_PAID) {
                textPaint.color = Color.parseColor("#198754")
            } else if (item.status == PaymentStatusType.UNPAID) {
                textPaint.color = Color.parseColor("#DC2626")
            } else if (item.status == PaymentStatusType.PARTIALLY_PAID) {
                textPaint.color = Color.parseColor("#D97706")
            }
            canvas.drawText(item.statusLabelBn, col6, currentY + 15f, textPaint)
            textPaint.color = oldColor

            currentY += 22f
        }

        // Summary Cards
        currentY += 20f
        paint.color = Color.parseColor("#D4EEDF")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(25f, currentY, 195f, currentY + 60f), 6f, 6f, paint)
        textPaint.color = Color.parseColor("#042B1A")
        textPaint.textSize = 10f
        canvas.drawText("মোট নির্ধারিত প্রাপ্য:", 35f, currentY + 24f, textPaint)
        textPaint.textSize = 14f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(BengaliUtils.formatTaka(summary.totalDue), 35f, currentY + 48f, textPaint)

        paint.color = Color.parseColor("#C2F0D4")
        canvas.drawRoundRect(RectF(210f, currentY, 380f, currentY + 60f), 6f, 6f, paint)
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 10f
        canvas.drawText("মোট পরিশোধিত সঞ্চয়:", 220f, currentY + 24f, textPaint)
        textPaint.textSize = 14f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(BengaliUtils.formatTaka(summary.totalPaid), 220f, currentY + 48f, textPaint)

        paint.color = if (summary.totalArrears > 0) Color.parseColor("#FFDAD6") else Color.parseColor("#E9F1EB")
        canvas.drawRoundRect(RectF(395f, currentY, pageWidth - 25f, currentY + 60f), 6f, 6f, paint)
        textPaint.color = if (summary.totalArrears > 0) Color.parseColor("#BA1A1A") else Color.parseColor("#181D19")
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 10f
        canvas.drawText("মোট বকেয়া পাওনা:", 405f, currentY + 24f, textPaint)
        textPaint.textSize = 14f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(BengaliUtils.formatTaka(summary.totalArrears), 405f, currentY + 48f, textPaint)

        // Signatures area
        val sigY = pageHeight - 110f
        paint.color = Color.parseColor("#727972")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawLine(40f, sigY, 160f, sigY, paint)
        canvas.drawLine(pageWidth - 160f, sigY, pageWidth - 40f, sigY, paint)

        textPaint.color = Color.parseColor("#181D19")
        textPaint.textSize = 9.5f
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("হিসাবরক্ষক / কোষাধ্যক্ষ", 100f, sigY + 16f, textPaint)
        canvas.drawText("সভাপতি / সাধারণ সম্পাদক", pageWidth - 100f, sigY + 16f, textPaint)

        // Footer Note
        textPaint.textSize = 8.5f
        textPaint.color = Color.parseColor("#727972")
        canvas.drawText("এই বিবরণীটি মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতির ডিজিটাল লেজার রেকর্ড হতে প্রস্তুতকৃত এবং যাচাইকৃত।", pageWidth / 2f, pageHeight - 40f, textPaint)

        document.finishPage(page)

        return try {
            val file = File(context.cacheDir, "statement_${member.memberNumber}.pdf")
            val outputStream = FileOutputStream(file)
            document.writeTo(outputStream)
            outputStream.close()
            document.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            document.close()
            null
        }
    }

    fun generateReceiptPdf(
        context: Context,
        transaction: SavingsTransactionEntity,
        member: MemberEntity,
        settings: SocietySettingsEntity,
        arrearsAfterTx: Double
    ): File? {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 420 // Half A4 landscape slip
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Outer Border
        paint.color = Color.parseColor("#0D5C3A")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawRect(15f, 15f, pageWidth - 15f, pageHeight - 15f, paint)

        // Inner Border
        paint.color = Color.parseColor("#C59B27")
        paint.strokeWidth = 1f
        canvas.drawRect(18f, 18f, pageWidth - 18f, pageHeight - 18f, paint)

        // Top Header
        paint.color = Color.parseColor("#0D5C3A")
        paint.style = Paint.Style.FILL
        canvas.drawRect(18f, 18f, pageWidth - 18f, 75f, paint)

        textPaint.color = Color.WHITE
        textPaint.textSize = 16f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(settings.societyNameBn, pageWidth / 2f, 44f, textPaint)

        textPaint.textSize = 10f
        textPaint.typeface = Typeface.DEFAULT
        canvas.drawText("${settings.location} • অফিস কপি ও গ্রাহক রসিদ", pageWidth / 2f, 62f, textPaint)

        // Receipt Title Badge
        paint.color = Color.parseColor("#C59B27")
        canvas.drawRoundRect(RectF(pageWidth / 2f - 90f, 82f, pageWidth / 2f + 90f, 104f), 6f, 6f, paint)
        textPaint.color = Color.parseColor("#3E2E00")
        textPaint.textSize = 11f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("মাসিক সঞ্চয় জমা রসিদ", pageWidth / 2f, 98f, textPaint)

        // Info Rows
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.parseColor("#181D19")
        textPaint.textSize = 11f

        val leftX = 40f
        val rightX = 330f

        canvas.drawText("রসিদ নং: ${transaction.receiptNumber}", leftX, 130f, textPaint)
        canvas.drawText("তারিখ: ${BengaliUtils.formatBengaliDate(transaction.paymentDate)}", rightX, 130f, textPaint)

        canvas.drawText("সদস্য নাম: ${member.bengaliName}", leftX, 155f, textPaint)
        canvas.drawText("সদস্য নং: ${member.memberNumber}", rightX, 155f, textPaint)

        canvas.drawText("মোবাইল: ${member.mobileNumber}", leftX, 180f, textPaint)
        canvas.drawText("সঞ্চয় মাস: ${BengaliUtils.getBengaliMonthName(transaction.month)}, ${BengaliUtils.toBengaliDigits(transaction.year)}", rightX, 180f, textPaint)

        canvas.drawText("পরিশোধ পদ্ধতি: ${BengaliUtils.getPaymentMethodBn(transaction.paymentMethod)}", leftX, 205f, textPaint)
        canvas.drawText("আদায়কারী: ${transaction.recordedBy}", rightX, 205f, textPaint)

        // Highlight Box for Amount
        val amtBoxTop = 225f
        paint.color = Color.parseColor("#D4EEDF")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(35f, amtBoxTop, pageWidth - 35f, amtBoxTop + 50f), 8f, 8f, paint)

        textPaint.color = Color.parseColor("#042B1A")
        textPaint.textSize = 12f
        canvas.drawText("জমার পরিমাণ:", 50f, amtBoxTop + 24f, textPaint)

        textPaint.textSize = 16f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(BengaliUtils.formatTaka(transaction.amount), 50f, amtBoxTop + 44f, textPaint)

        textPaint.textSize = 11f
        textPaint.typeface = Typeface.DEFAULT
        canvas.drawText("কথায়: ${BengaliUtils.amountInBengaliWords(transaction.amount)}", 200f, amtBoxTop + 26f, textPaint)
        canvas.drawText("জমা পরবর্তী মোট বকেয়া: ${BengaliUtils.formatTaka(arrearsAfterTx)}", 200f, amtBoxTop + 44f, textPaint)

        // Signatures
        val sigY = pageHeight - 55f
        paint.color = Color.parseColor("#727972")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawLine(50f, sigY, 180f, sigY, paint)
        canvas.drawLine(pageWidth - 180f, sigY, pageWidth - 50f, sigY, paint)

        textPaint.color = Color.parseColor("#181D19")
        textPaint.textSize = 10f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("আদায়কারীর স্বাক্ষর", 115f, sigY + 18f, textPaint)
        canvas.drawText("সদস্যের স্বাক্ষর", pageWidth - 115f, sigY + 18f, textPaint)

        document.finishPage(page)

        return try {
            val file = File(context.cacheDir, "receipt_${transaction.receiptNumber}.pdf")
            val outputStream = FileOutputStream(file)
            document.writeTo(outputStream)
            outputStream.close()
            document.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            document.close()
            null
        }
    }

    fun sharePdfFile(context: Context, file: File, title: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, title))
        } catch (e: Exception) {
            Toast.makeText(context, "ফাইল শেয়ার করতে সমস্যা হয়েছে: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportTransactionsCsv(
        context: Context,
        transactions: List<SavingsTransactionEntity>,
        membersMap: Map<Long, MemberEntity>
    ): File? {
        return try {
            val file = File(context.cacheDir, "transactions_report.csv")
            val fos = FileOutputStream(file)
            val header = "Receipt Number,Transaction ID,Member Number,Member Name,Month,Year,Amount,Date,Method,Status,Recorded By\n"
            fos.write(header.toByteArray())

            for (tx in transactions) {
                val member = membersMap[tx.memberId]
                val line = "${tx.receiptNumber},${tx.transactionId},\"${member?.memberNumber ?: ""}\",\"${member?.bengaliName ?: ""}\",${tx.month},${tx.year},${tx.amount},${tx.paymentDate},${tx.paymentMethod},${tx.status},\"${tx.recordedBy}\"\n"
                fos.write(line.toByteArray())
            }
            fos.close()
            file
        } catch (e: Exception) {
            null
        }
    }

    fun generateMonthlyCollectionSheetPdf(
        context: Context,
        month: Int,
        year: Int,
        members: List<MemberEntity>,
        transactions: List<SavingsTransactionEntity>,
        settings: SocietySettingsEntity
    ): File? {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        canvas.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Header Background
        paint.color = Color.parseColor("#0D5C3A")
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 95f, paint)

        // Gold line
        paint.color = Color.parseColor("#C59B27")
        paint.strokeWidth = 3f
        canvas.drawLine(0f, 95f, pageWidth.toFloat(), 95f, paint)

        // Draw Society Logo
        val logoBitmap = try {
            BitmapFactory.decodeResource(context.resources, R.drawable.society_logo)
        } catch (_: Exception) { null }

        if (logoBitmap != null) {
            canvas.drawBitmap(logoBitmap, null, RectF(20f, 15f, 85f, 80f), paint)
        }

        // Header Titles
        textPaint.color = Color.WHITE
        textPaint.textSize = 16f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(settings.societyNameBn, pageWidth / 2f + 25f, 36f, textPaint)

        textPaint.textSize = 10f
        textPaint.typeface = Typeface.DEFAULT
        canvas.drawText("${settings.societyNameEn} • ${settings.location}", pageWidth / 2f + 25f, 54f, textPaint)

        textPaint.textSize = 12f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.color = Color.parseColor("#FFD97D")
        val monthName = BengaliUtils.getBengaliMonthName(month)
        canvas.drawText("মাসিক সঞ্চয় আদায় ও সদস্য তালিকা বিবরণী — $monthName ${BengaliUtils.toBengaliDigits(year)}", pageWidth / 2f + 25f, 76f, textPaint)

        // Statistics Card
        val statTop = 106f
        paint.color = Color.parseColor("#F4F7F4")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(20f, statTop, pageWidth - 20f, statTop + 45f), 6f, 6f, paint)

        paint.color = Color.parseColor("#C2C9C1")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(RectF(20f, statTop, pageWidth - 20f, statTop + 45f), 6f, 6f, paint)

        // Calculate stats
        val targetTxs = transactions.filter { !it.isReversed && it.month == month && it.year == year }
        val memberPaidMap = mutableMapOf<Long, Double>()
        for (tx in targetTxs) {
            memberPaidMap[tx.memberId] = (memberPaidMap[tx.memberId] ?: 0.0) + tx.amount
        }
        val activeMembers = members.filter { it.status == "ACTIVE" }
        val paidCount = activeMembers.count { (memberPaidMap[it.id] ?: 0.0) >= settings.monthlySavingsAmount }
        val totalCollected = targetTxs.sumOf { it.amount }
        val unpaidCount = (activeMembers.size - paidCount).coerceAtLeast(0)
        val totalDue = unpaidCount * settings.monthlySavingsAmount

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 9.5f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.color = Color.parseColor("#0D5C3A")
        canvas.drawText("মোট সক্রিয় সদস্য: ${BengaliUtils.toBengaliDigits(activeMembers.size)} জন", 30f, statTop + 20f, textPaint)
        canvas.drawText("পরিশোধ করেছেন: ${BengaliUtils.toBengaliDigits(paidCount)} জন (মোট ${BengaliUtils.formatTaka(totalCollected)})", 30f, statTop + 36f, textPaint)

        textPaint.color = Color.parseColor("#BA1A1A")
        canvas.drawText("বকেয়া রয়েছে: ${BengaliUtils.toBengaliDigits(unpaidCount)} জন (মোট ${BengaliUtils.formatTaka(totalDue)})", 320f, statTop + 20f, textPaint)
        textPaint.color = Color.parseColor("#181D19")
        textPaint.typeface = Typeface.DEFAULT
        canvas.drawText("তারিখ: ${BengaliUtils.getCurrentTimestampFormatted()}", 320f, statTop + 36f, textPaint)

        // Table Header
        val tableTop = 160f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#0D5C3A")
        canvas.drawRect(20f, tableTop, pageWidth - 20f, tableTop + 22f, paint)

        textPaint.color = Color.WHITE
        textPaint.textSize = 9.5f
        textPaint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("ক্র.", 26f, tableTop + 15f, textPaint)
        canvas.drawText("আইডি", 50f, tableTop + 15f, textPaint)
        canvas.drawText("সদস্য নাম", 115f, tableTop + 15f, textPaint)
        canvas.drawText("মোবাইল", 255f, tableTop + 15f, textPaint)
        canvas.drawText("এই মাসের জমা", 355f, tableTop + 15f, textPaint)
        canvas.drawText("স্ট্যাটাস", 450f, tableTop + 15f, textPaint)
        canvas.drawText("স্বাক্ষর/মন্তব্য", 515f, tableTop + 15f, textPaint)

        // Rows
        var currentY = tableTop + 22f
        val rowHeight = 22f
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 9f

        activeMembers.forEachIndexed { index, m ->
            if (currentY + rowHeight <= pageHeight - 75f) {
                if (index % 2 == 1) {
                    paint.color = Color.parseColor("#F9FAF9")
                    canvas.drawRect(20f, currentY, pageWidth - 20f, currentY + rowHeight, paint)
                }
                paint.color = Color.parseColor("#E0E5E0")
                paint.strokeWidth = 0.5f
                canvas.drawLine(20f, currentY + rowHeight, pageWidth - 20f, currentY + rowHeight, paint)

                val paidAmount = memberPaidMap[m.id] ?: 0.0
                val isPaid = paidAmount >= settings.monthlySavingsAmount

                textPaint.color = Color.parseColor("#181D19")
                canvas.drawText("${index + 1}", 26f, currentY + 15f, textPaint)
                canvas.drawText(m.memberNumber, 50f, currentY + 15f, textPaint)
                canvas.drawText(m.bengaliName, 115f, currentY + 15f, textPaint)
                canvas.drawText(m.mobileNumber, 255f, currentY + 15f, textPaint)

                if (isPaid) {
                    textPaint.color = Color.parseColor("#0D5C3A")
                    textPaint.typeface = Typeface.DEFAULT_BOLD
                    canvas.drawText(BengaliUtils.formatTaka(paidAmount), 355f, currentY + 15f, textPaint)
                    canvas.drawText("✓ পরিশোধিত", 450f, currentY + 15f, textPaint)
                } else {
                    textPaint.color = Color.parseColor("#BA1A1A")
                    textPaint.typeface = Typeface.DEFAULT_BOLD
                    canvas.drawText(BengaliUtils.formatTaka(paidAmount), 355f, currentY + 15f, textPaint)
                    canvas.drawText("✕ বকেয়া", 450f, currentY + 15f, textPaint)
                }
                textPaint.typeface = Typeface.DEFAULT

                currentY += rowHeight
            }
        }

        // Signatures area
        val sigY = pageHeight - 65f
        paint.color = Color.parseColor("#727972")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.8f
        canvas.drawLine(40f, sigY, 170f, sigY, paint)
        canvas.drawLine(pageWidth - 170f, sigY, pageWidth - 40f, sigY, paint)

        textPaint.color = Color.parseColor("#181D19")
        textPaint.textSize = 9f
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("কোষাধ্যক্ষ / হিসাবরক্ষক", 105f, sigY + 14f, textPaint)
        canvas.drawText("সভাপতি / সাধারণ সম্পাদক", pageWidth - 105f, sigY + 14f, textPaint)

        // Footer note
        textPaint.textSize = 8f
        textPaint.color = Color.parseColor("#727972")
        canvas.drawText("মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি • বাঁশখালী, চট্টগ্রাম • সঞ্চয়ে সমৃদ্ধি, ঐক্যে উন্নয়ন", pageWidth / 2f, pageHeight - 18f, textPaint)

        document.finishPage(page)

        return try {
            val file = File(context.cacheDir, "monthly_collection_${year}_${month}.pdf")
            val outputStream = FileOutputStream(file)
            document.writeTo(outputStream)
            outputStream.close()
            document.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            document.close()
            null
        }
    }
}
