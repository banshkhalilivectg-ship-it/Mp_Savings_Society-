package com.example.domain

import com.example.data.model.MemberEntity
import com.example.data.model.PaymentAllocationEntity
import com.example.data.model.SavingsTransactionEntity
import com.example.data.model.SocietySettingsEntity

enum class PaymentStatusType {
    FULLY_PAID,
    PARTIALLY_PAID,
    UNPAID,
    NOT_APPLICABLE
}

data class MonthlyLedgerItem(
    val month: Int,
    val year: Int,
    val monthNameBn: String,
    val dueAmount: Double,
    val paidAmount: Double,
    val balance: Double, // due - paid
    val status: PaymentStatusType,
    val statusLabelBn: String,
    val paymentDate: String? = null,
    val receiptNumber: String? = null
)

data class MemberArrearsSummary(
    val memberId: Long,
    val memberNumber: String,
    val bengaliName: String,
    val mobileNumber: String,
    val totalDue: Double,
    val totalPaid: Double,
    val totalArrears: Double,
    val unpaidMonthsCount: Int,
    val partialMonthsCount: Int,
    val fullyPaidMonthsCount: Int,
    val monthlyItems: List<MonthlyLedgerItem>
)

object ArrearsCalculator {

    fun calculateForMember(
        member: MemberEntity,
        settings: SocietySettingsEntity,
        allocations: List<PaymentAllocationEntity>,
        transactions: List<SavingsTransactionEntity>,
        targetYear: Int = 2026,
        targetMonth: Int = 10
    ): MemberArrearsSummary {
        val monthlyDue = settings.monthlySavingsAmount

        // Determine start year and month
        var memberStartYear = settings.startYear
        var memberStartMonth = settings.startMonth

        try {
            val parts = member.joinDate.split("-")
            if (parts.size >= 2) {
                val joinYr = parts[0].toInt()
                val joinMo = parts[1].toInt()
                if (joinYr > memberStartYear || (joinYr == memberStartYear && joinMo > memberStartMonth)) {
                    memberStartYear = joinYr
                    memberStartMonth = joinMo
                }
            }
        } catch (_: Exception) {}

        // Map non-reversed allocations by (year, month)
        val validAllocations = allocations.filter { !it.isReversed && it.memberId == member.id }
        val paidMap = mutableMapOf<Pair<Int, Int>, Double>()
        for (a in validAllocations) {
            val key = Pair(a.year, a.month)
            paidMap[key] = (paidMap[key] ?: 0.0) + a.allocatedAmount
        }

        // Map transactions for dates and receipts
        val validTransactions = transactions.filter { !it.isReversed && it.memberId == member.id }
        val txInfoMap = mutableMapOf<Pair<Int, Int>, Pair<String, String>>()
        for (tx in validTransactions) {
            val key = Pair(tx.year, tx.month)
            txInfoMap[key] = Pair(tx.paymentDate, tx.receiptNumber)
        }

        val monthlyItems = mutableListOf<MonthlyLedgerItem>()
        var totalDue = 0.0
        var totalPaid = 0.0
        var unpaidCount = 0
        var partialCount = 0
        var fullyPaidCount = 0

        // Iterate through all months of the current year (1..12) or across years from start
        val currentYear = targetYear
        for (mo in 1..12) {
            val isBeforeMemberJoin = (currentYear < memberStartYear) ||
                    (currentYear == memberStartYear && mo < memberStartMonth)
            val isFutureMonth = (currentYear > targetYear) ||
                    (currentYear == targetYear && mo > targetMonth)

            val monthName = BengaliUtils.getBengaliMonthName(mo)
            val key = Pair(currentYear, mo)
            val paid = paidMap[key] ?: 0.0
            val txInfo = txInfoMap[key]

            if (isBeforeMemberJoin) {
                monthlyItems.add(
                    MonthlyLedgerItem(
                        month = mo,
                        year = currentYear,
                        monthNameBn = monthName,
                        dueAmount = 0.0,
                        paidAmount = paid,
                        balance = 0.0,
                        status = PaymentStatusType.NOT_APPLICABLE,
                        statusLabelBn = "প্রযোজ্য নয়",
                        paymentDate = txInfo?.first,
                        receiptNumber = txInfo?.second
                    )
                )
            } else if (isFutureMonth) {
                // If member prepaid advance for future month
                val status = if (paid >= monthlyDue) PaymentStatusType.FULLY_PAID
                else if (paid > 0.0) PaymentStatusType.PARTIALLY_PAID
                else PaymentStatusType.NOT_APPLICABLE

                val label = when (status) {
                    PaymentStatusType.FULLY_PAID -> "অগ্রিম জমা"
                    PaymentStatusType.PARTIALLY_PAID -> "আংশিক অগ্রিম"
                    else -> "প্রযোজ্য নয়"
                }

                if (paid > 0.0) {
                    totalPaid += paid
                }

                monthlyItems.add(
                    MonthlyLedgerItem(
                        month = mo,
                        year = currentYear,
                        monthNameBn = monthName,
                        dueAmount = 0.0, // Future month does not count as overdue
                        paidAmount = paid,
                        balance = 0.0,
                        status = status,
                        statusLabelBn = label,
                        paymentDate = txInfo?.first,
                        receiptNumber = txInfo?.second
                    )
                )
            } else {
                // Past or current elapsed month
                totalDue += monthlyDue
                totalPaid += paid
                val balance = (monthlyDue - paid).coerceAtLeast(0.0)

                val status: PaymentStatusType
                val statusLabel: String

                if (paid >= monthlyDue) {
                    status = PaymentStatusType.FULLY_PAID
                    statusLabel = "জমা সম্পন্ন"
                    fullyPaidCount++
                } else if (paid > 0.0) {
                    status = PaymentStatusType.PARTIALLY_PAID
                    statusLabel = "আংশিক জমা"
                    partialCount++
                } else {
                    status = PaymentStatusType.UNPAID
                    statusLabel = "বকেয়া"
                    unpaidCount++
                }

                monthlyItems.add(
                    MonthlyLedgerItem(
                        month = mo,
                        year = currentYear,
                        monthNameBn = monthName,
                        dueAmount = monthlyDue,
                        paidAmount = paid,
                        balance = balance,
                        status = status,
                        statusLabelBn = statusLabel,
                        paymentDate = txInfo?.first,
                        receiptNumber = txInfo?.second
                    )
                )
            }
        }

        val totalArrears = (totalDue - totalPaid).coerceAtLeast(0.0)

        return MemberArrearsSummary(
            memberId = member.id,
            memberNumber = member.memberNumber,
            bengaliName = member.bengaliName,
            mobileNumber = member.mobileNumber,
            totalDue = totalDue,
            totalPaid = totalPaid,
            totalArrears = totalArrears,
            unpaidMonthsCount = unpaidCount,
            partialMonthsCount = partialCount,
            fullyPaidMonthsCount = fullyPaidCount,
            monthlyItems = monthlyItems
        )
    }
}
