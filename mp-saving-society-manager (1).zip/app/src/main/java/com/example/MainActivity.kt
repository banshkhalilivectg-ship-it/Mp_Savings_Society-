package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppRole
import com.example.ui.ScreenDestination
import com.example.ui.SocietyViewModel
import com.example.ui.components.SocietyTopBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminSettingsScreen
import com.example.ui.screens.ArrearsReportScreen
import com.example.ui.screens.AuditLogScreen
import com.example.ui.screens.BankRecordsScreen
import com.example.ui.screens.CollectionSheetScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.FirebaseSetupGuideScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MemberDashboardScreen
import com.example.ui.screens.MemberDetailScreen
import com.example.ui.screens.MemberDirectoryScreen
import com.example.ui.screens.NoticesScreen
import com.example.ui.screens.SavingsEntryScreen
import com.example.ui.screens.TransactionHistoryScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: SocietyViewModel = viewModel()
                MainAppContent(viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: SocietyViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val loggedInMember by viewModel.loggedInMember.collectAsState()
    val selectedMemberForDetail by viewModel.selectedMemberForDetail.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var showMoreMenu by remember { mutableStateOf(false) }

    val canNavigateBack = currentScreen != ScreenDestination.ADMIN_DASHBOARD &&
            currentScreen != ScreenDestination.MEMBER_DASHBOARD &&
            currentScreen != ScreenDestination.LOGIN

    BackHandler(enabled = canNavigateBack) {
        if (currentRole == AppRole.SUPER_ADMIN) {
            viewModel.navigateTo(ScreenDestination.ADMIN_DASHBOARD)
        } else {
            viewModel.navigateTo(ScreenDestination.MEMBER_DASHBOARD)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentScreen != ScreenDestination.LOGIN) {
                SocietyTopBar(
                    title = settings?.societyNameBn ?: "মৌলভী পাড়া জনকল্যাণ সঞ্চয় সমিতি",
                    role = currentRole,
                    memberName = loggedInMember?.bengaliName,
                    canNavigateBack = canNavigateBack,
                    onNavigateBack = {
                        if (currentRole == AppRole.SUPER_ADMIN) {
                            viewModel.navigateTo(ScreenDestination.ADMIN_DASHBOARD)
                        } else {
                            viewModel.navigateTo(ScreenDestination.MEMBER_DASHBOARD)
                        }
                    },
                    onLogout = { viewModel.logout() },
                    onSwitchRole = { viewModel.logout() }
                )
            }
        },
        bottomBar = {
            if (currentScreen != ScreenDestination.LOGIN && currentRole == AppRole.SUPER_ADMIN) {
                NavigationBar(
                    containerColor = Color.White,
                    contentColor = EmeraldPrimary
                ) {
                    NavigationBarItem(
                        selected = currentScreen == ScreenDestination.ADMIN_DASHBOARD,
                        onClick = { viewModel.navigateTo(ScreenDestination.ADMIN_DASHBOARD) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                        label = { Text("ড্যাশবোর্ড") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = Color(0xFFD4EEDF)
                        ),
                        modifier = Modifier.testTag("nav_tab_dashboard")
                    )

                    NavigationBarItem(
                        selected = currentScreen == ScreenDestination.SAVINGS_ENTRY,
                        onClick = { viewModel.navigateTo(ScreenDestination.SAVINGS_ENTRY) },
                        icon = { Icon(Icons.Default.AddCard, contentDescription = null) },
                        label = { Text("জমা এন্ট্রি") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = Color(0xFFD4EEDF)
                        ),
                        modifier = Modifier.testTag("nav_tab_savings")
                    )

                    NavigationBarItem(
                        selected = currentScreen == ScreenDestination.MEMBER_DIRECTORY || currentScreen == ScreenDestination.MEMBER_DETAIL,
                        onClick = { viewModel.navigateTo(ScreenDestination.MEMBER_DIRECTORY) },
                        icon = { Icon(Icons.Default.People, contentDescription = null) },
                        label = { Text("সদস্য") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = Color(0xFFD4EEDF)
                        ),
                        modifier = Modifier.testTag("nav_tab_members")
                    )

                    NavigationBarItem(
                        selected = currentScreen == ScreenDestination.ARREARS_REPORT,
                        onClick = { viewModel.navigateTo(ScreenDestination.ARREARS_REPORT) },
                        icon = { Icon(Icons.Default.Warning, contentDescription = null) },
                        label = { Text("বকেয়া") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = Color(0xFFD4EEDF)
                        ),
                        modifier = Modifier.testTag("nav_tab_arrears")
                    )

                    NavigationBarItem(
                        selected = currentScreen == ScreenDestination.EXPENSES ||
                                currentScreen == ScreenDestination.BANK_RECORDS ||
                                currentScreen == ScreenDestination.NOTICES ||
                                currentScreen == ScreenDestination.AUDIT_LOG ||
                                currentScreen == ScreenDestination.ADMIN_SETTINGS ||
                                currentScreen == ScreenDestination.FIREBASE_SETUP,
                        onClick = { showMoreMenu = true },
                        icon = {
                            Icon(Icons.Default.MoreHoriz, contentDescription = null)
                            DropdownMenu(
                                expanded = showMoreMenu,
                                onDismissRequest = { showMoreMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("📋 মাসিক কালেকশন শিট (হোয়াটসঅ্যাপ)") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.COLLECTION_SHEET)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("সকল লেনদেন ও লেজার") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.TRANSACTION_HISTORY)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("খরচ হিসাব ও ভাউচার") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.EXPENSES)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("ব্যাংক ও ক্যাশ হিসাব") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.BANK_RECORDS)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("নোটিশ ও ঘোষণা বোর্ড") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.NOTICES)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("এডমিন ও এডিটর ইনভাইট") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.ADMIN_MANAGEMENT)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("নিরাপত্তা ও অডিট লগ") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.AUDIT_LOG)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("সমিতির নিয়ম ও সেটিংস") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.ADMIN_SETTINGS)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("ফায়ারবেস ক্লাউড গাইড") },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.navigateTo(ScreenDestination.FIREBASE_SETUP)
                                    }
                                )
                            }
                        },
                        label = { Text("আরও") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = Color(0xFFD4EEDF)
                        ),
                        modifier = Modifier.testTag("nav_tab_more")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ScreenDestination.LOGIN -> LoginScreen(viewModel)
                ScreenDestination.ADMIN_DASHBOARD -> AdminDashboardScreen(viewModel)
                ScreenDestination.MEMBER_DIRECTORY -> MemberDirectoryScreen(viewModel)
                ScreenDestination.MEMBER_DETAIL -> {
                    val member = selectedMemberForDetail
                    if (member != null) {
                        MemberDetailScreen(member, viewModel)
                    } else {
                        MemberDirectoryScreen(viewModel)
                    }
                }
                ScreenDestination.SAVINGS_ENTRY -> SavingsEntryScreen(viewModel)
                ScreenDestination.COLLECTION_SHEET -> CollectionSheetScreen(viewModel)
                ScreenDestination.TRANSACTION_HISTORY -> TransactionHistoryScreen(viewModel)
                ScreenDestination.ARREARS_REPORT -> ArrearsReportScreen(viewModel)
                ScreenDestination.EXPENSES -> ExpensesScreen(viewModel)
                ScreenDestination.BANK_RECORDS -> BankRecordsScreen(viewModel)
                ScreenDestination.NOTICES -> NoticesScreen(viewModel)
                ScreenDestination.AUDIT_LOG -> AuditLogScreen(viewModel)
                ScreenDestination.ADMIN_SETTINGS -> AdminSettingsScreen(viewModel)
                ScreenDestination.ADMIN_MANAGEMENT -> com.example.ui.screens.AdminManagementScreen(viewModel)
                ScreenDestination.FIREBASE_SETUP -> FirebaseSetupGuideScreen(viewModel)
                ScreenDestination.MEMBER_DASHBOARD -> {
                    val member = loggedInMember
                    if (member != null) {
                        MemberDashboardScreen(member, viewModel)
                    } else {
                        LoginScreen(viewModel)
                    }
                }
            }
        }
    }
}
